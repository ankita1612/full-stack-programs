import { HttpStatus, Injectable } from '@nestjs/common';
import { CreateAvatarDto } from './dto/create-avatar.dto';
import { Avatar } from './entity/avatar.entity';
import { ILike, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { logger } from 'src/logger/winston.logger';
import { ListDto } from 'src/user/dto/list.dto';

@Injectable()
export class AvatarService {

    constructor(
        @InjectRepository(Avatar)
        private readonly avatarRepository: Repository<Avatar>,
    ) {}


    /**get all avatar */
    async get(reqQuery:ListDto,baseUrl) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;


            const whereCondition: any[] = [];
            if (reqQuery.search) {
                const searchValue = ILike(`%${reqQuery.search}%`);
                whereCondition.push(
                    { name:  searchValue },
                    { gender: searchValue },
                );
            }
            
            const [result, count] = await this.avatarRepository.findAndCount({
                where: whereCondition.length > 0 ? whereCondition : undefined, 
                select: {
                    id: true,
                    name: true,
                    gender: true,
                    profile_pic: true,
                    created_at: true,
                },
                order: {
                    created_at: 'ASC',
                },
                take: limit,
                skip: offset,
            });

            const updatedResult = result.map((avatar) => ({
                ...avatar,
                profile_path: avatar.profile_pic, 
                profile_pic: avatar.profile_pic
                    ? `${baseUrl}/${avatar.profile_pic}` 
                    : null, 
            }));

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'All avatar list.',
                data: {
                    docs: updatedResult,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    /**add avatar */
    async add(createAvatarDto:CreateAvatarDto)
    {
        try {
            const avatar = await this.avatarRepository.save(createAvatarDto);
            return {
                statusCode: HttpStatus.CREATED,
                message: 'avatar has been created.',
                data: avatar,
            };


        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**delete */
    async delete(id:number)
    {
        try {
            const avatar = await this.avatarRepository.delete(id);
            return {
                statusCode: HttpStatus.OK,
                message: 'avatar has been deleted.',
                data: {},
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}
