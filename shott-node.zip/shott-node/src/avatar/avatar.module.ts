import { Module } from '@nestjs/common';
import { AvatarController } from './avatar.controller';
import { AvatarService } from './avatar.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Avatar } from './entity/avatar.entity';

@Module({
  controllers: [AvatarController],
  providers: [AvatarService],
  exports:[AvatarService],
  imports:[TypeOrmModule.forFeature([Avatar])],
})
export class AvatarModule {}
