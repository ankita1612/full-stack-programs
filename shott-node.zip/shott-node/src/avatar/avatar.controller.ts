import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Query, Req, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { ListDto } from 'src/user/dto/list.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { HttpException, HttpStatus } from '@nestjs/common';
import { diskStorage } from 'multer';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { Roles } from 'src/roles-permissions.decorator';
import { Role } from 'src/common/enums/role.enum';
import { AvatarService } from './avatar.service';
import { CreateAvatarDto } from './dto/create-avatar.dto';
import { Request } from 'express';

@Controller('avatar')
@UseGuards(JwtAuthGuard)

export class AvatarController {
    constructor(private readonly avatarService: AvatarService) {}

    @Get()
    async fetch(
        @Req() request: Request,
        @Query() reqQuery:ListDto) {
        // Dynamically construct the base URL
        const baseUrl = `${request.protocol}://${request.get('host')}`;
        const record = await this.avatarService.get(reqQuery,baseUrl);
        return record;
    }

    @UseInterceptors(
        FileInterceptor('profile_pic', {
            storage: diskStorage({
                destination: 'public/user/avatar',
                filename: (req, file, cb) => {
                    const uniqueSuffix =
                        Date.now() + '-' + Math.round(Math.random() * 1e9);
                    const nameTab = file.originalname.split('.');
                    const subArray = nameTab.slice(0, -1);
                    const originalName = subArray.join('');
                    const ext = `.${nameTab[nameTab.length - 1]}`;
                    const filename = `${originalName}-${uniqueSuffix}${ext}`;
                    cb(null, filename);
                },
            }),
        }),
    )

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Post('/add')
    async add(
        @Body() createAvatarDto:CreateAvatarDto,
        @UploadedFile() file: Express.Multer.File
    ) {
        if (file) {
            createAvatarDto.profile_pic = file.path;
        }else{
            throw new HttpException(
                'Profile pic is required.',
                HttpStatus.BAD_REQUEST,
            );
        } 
        const avatar = await this.avatarService.add(createAvatarDto);
        return avatar;  
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Delete('/:id')
    async delete(
        @Param('id',ParseIntPipe) id:number
    ) {
        const avatar = await this.avatarService.delete(id);
        return avatar;
        
    }
}
