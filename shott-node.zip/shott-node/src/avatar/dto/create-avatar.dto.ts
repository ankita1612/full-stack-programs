import { IsOptional, IsString } from "class-validator";


export class CreateAvatarDto{

    @IsString()
    @IsOptional()
    name:string;

    @IsString()
    @IsOptional()
    gender:string;

    @IsString()
    @IsOptional()
    profile_pic: string;

}