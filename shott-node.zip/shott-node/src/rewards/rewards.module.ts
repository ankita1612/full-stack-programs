import { Module } from '@nestjs/common';
import { RewardsController } from './rewards.controller';
import { RewardsService } from './rewards.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Rewards } from './entity/rewards.entity';
import { UserRewards } from './entity/user-rewards.entity';
import { UserModule } from 'src/user/user.module';

@Module({
  controllers: [RewardsController],
  providers: [RewardsService],
  exports:[RewardsService],
  imports:[TypeOrmModule.forFeature([Rewards,UserRewards]),UserModule]

})
export class RewardsModule {}
