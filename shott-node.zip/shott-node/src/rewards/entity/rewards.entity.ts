import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('rewards')
export class Rewards {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: 'int' })
    coins: number;

    @Column({ type: 'int' })
    days: number;

    @Column({ default: true })
    status: boolean;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
