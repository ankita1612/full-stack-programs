import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { RewardsService } from './rewards.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RewardDto } from './dto/rewards.dto';
import { UserRewardDto } from './dto/user-rewards.dto';
import { Permissions, Roles } from 'src/roles-permissions.decorator';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { ListDto } from 'src/user/dto/list.dto';
import { PermissionModule } from 'src/common/enums/user.permission';
import { Role } from 'src/common/enums/role.enum';

@Controller('rewards')

@UseGuards(JwtAuthGuard) 

export class RewardsController {
    constructor(private readonly rewardService: RewardsService) {}

    @Get()
    async fetch(@Query()reqQuery: ListDto) {
        const record = await this.rewardService.get(reqQuery);
        return record;
    }

    @Post('/collect')
    async collect(
        @Req() req, 
        @Body() userRewardDto: UserRewardDto 
    ) {
        return this.rewardService.collectReward(req.user.id, userRewardDto);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Reward)
    @Post('/create')
    async create(
        @Req() req,
        @Body() rewardDto: RewardDto 
    ) {
        return this.rewardService.create(rewardDto);
    }


    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Reward)
    @Patch('/:id')
    async update(
        @Body() body: any,
        @Param('id', ParseIntPipe) id: number,
    ) {
        return this.rewardService.update(body,id);
    }


    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Reward)
    @Delete('/:id')
    async delete(@Param('id',ParseIntPipe) id:number) {
        const record = await this.rewardService.delete(id);
        return record;
    }
}
