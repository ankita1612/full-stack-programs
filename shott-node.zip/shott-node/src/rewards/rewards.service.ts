import { HttpException, HttpStatus, Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Rewards } from './entity/rewards.entity';
import { Equal, Like, Repository } from 'typeorm';
import { logger } from 'src/logger/winston.logger';
import { UserRewardDto } from './dto/user-rewards.dto';
import { UserRewards } from './entity/user-rewards.entity';
import { RewardDto } from './dto/rewards.dto';
import { UserService } from 'src/user/user.service';
import { ListDto } from 'src/user/dto/list.dto';

@Injectable()
export class RewardsService implements OnModuleInit {

    constructor(
        @InjectRepository(Rewards)
        private readonly rewardRepository: Repository<Rewards>,

        @InjectRepository(UserRewards)
        private readonly userRewardsRepository: Repository<UserRewards>,

        private readonly userService: UserService
    ) {}
    

    async onModuleInit() {
        const rewardCount = await this.rewardRepository.count();

        if(rewardCount === 0){
            // Seed data
            await this.rewardRepository.save([
                {
                    coins: 50,
                    days: 1,
                },
                {
                    coins: 100,
                    days: 2,
                },
                {
                    coins: 150,
                    days: 3,
                },
                {
                    coins: 200,
                    days: 4,
                },
                {
                    coins: 250,
                    days: 5,
                },
                {
                    coins: 300,
                    days: 6,
                },
            ]);
        }
    }
    /**fetch all rewards **/
    async get(reqQuery:ListDto): Promise<any> {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            // Initialize where condition
            const whereCondition: any[] = [];

            // Only add conditions if search is not empty
            if (reqQuery.search) {
                const searchValue = Number(reqQuery.search);
                whereCondition.push(
                    { coins: Equal(searchValue) },
                    { days: Equal(searchValue) }
                );
            }
             // Fetch the data using findAndCount for pagination
            const [result, count] = await this.rewardRepository.findAndCount({
                where: whereCondition.length > 0 ? whereCondition : undefined, 
                select: {
                    id:true,
                    coins: true,
                    status: true,
                    days: true,
                    created_at: true,
                },
                order: {
                    created_at: 'ASC',
                },
                take: limit,
                skip: offset,
            });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'All reward data.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    /***collect reward ***/
    async collectReward(userId:number, userRewardDto: UserRewardDto) {
        try {
            const rewardExist = await this.getExistingReward(userId,userRewardDto.reward_id);
            if (rewardExist) {
                throw new HttpException(
                    'Reward already collected.', 
                    HttpStatus.BAD_REQUEST
                )
            }
            // Add the user ID to the reward data
            const userRewardData = {
                ...userRewardDto,
                user_id: userId, 
            };

            // Save the reward data to the database
            const savedReward = await this.userRewardsRepository.save(userRewardData);

            if(savedReward){
                await this.updateUserCoins(userId,userRewardDto.coin_withdrawal);
            }

            // Return the collected reward data
            return {
                message: 'Reward collected successfully.',
                statusCode: HttpStatus.OK,
                data: savedReward,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

   /** Find existing reward record if available */
    async getExistingReward(userId: number, rewardId: number) {
        try {
            return await this.userRewardsRepository.findOne({ 
                where: { 
                    user_id: userId,
                    reward_id: rewardId 
                } 
            });
        } catch (error) {
            logger.error(error);
            throw new Error('An error occurred while fetching the reward.');
        }
    }

    /**create **/
    async create(rewardDto:RewardDto){
        try {
            const rewardExist = await this.getDuplicateReward(rewardDto.coins,rewardDto.days);
            if (rewardExist) {
                throw new HttpException(
                    'Reward already Exist.', 
                    HttpStatus.BAD_REQUEST
                )
            }
            // Await the result of the asynchronous operation
            const rewardsData = await this.rewardRepository.save(rewardDto);

            // Return a custom response structure
            return {
                message: 'Rewards has been created.',
                statusCode: HttpStatus.CREATED,
                data: rewardsData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**update **/
    async update(rewardDto:RewardDto,id:number){
        try {
            const rewardExist = await this.getDuplicateReward(rewardDto.coins,rewardDto.days);
            if (rewardExist && rewardExist.id !== id) {
                throw new HttpException(
                    'Reward already Exist.', 
                    HttpStatus.BAD_REQUEST
                )
            }
            // Await the result of the asynchronous operation
            const rewardsData = await this.rewardRepository.update(id,rewardDto);

            // Return a custom response structure
            return {
                message: 'Rewards record has been update.',
                statusCode: HttpStatus.OK,
                data: rewardsData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

     /** Find duplicate reward record if available */
     async getDuplicateReward(coins: number, days: number) {
        try {
            return await this.rewardRepository.findOne({ 
                where: { 
                    coins: coins,
                    days: days 
                } 
            });
        } catch (error) {
            logger.error(error);
            throw new Error('An error occurred while fetching the reward.');
        }
    }
    

    /**delete **/
    async delete(id:number)
    {
        try {
            const rewardData = await this.rewardRepository.delete(id);

            return {
                message: 'Reward record has been deleted.',
                statusCode: HttpStatus.OK,
                data: rewardData,
            };
        } catch (error) {
            logger.error(error);
            throw new Error('An error occurred while deleting the reward.');
        }
    }
    /**update user coins **/
    async updateUserCoins(user_id:number,coins:number)
    {
        try {
            const user = await this.userService.updateCoins(user_id,coins)
        } catch (error) {
            logger.error(error);
            throw new Error('An error occurred while updating the reward for user table.');
        }
    }
    
}
