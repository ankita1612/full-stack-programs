import { IsBoolean, IsNotEmpty, IsNumber } from "class-validator";

export class RewardDto {

    @IsNotEmpty()
    @IsNumber()
    coins: number;

    @IsNotEmpty()
    @IsNumber()
    days: number;

    @IsBoolean()
    status: boolean;

}