import { IsNotEmpty,IsNumber } from "class-validator";

export class UserRewardDto{

    @IsNumber()
    @IsNotEmpty()
    coin_withdrawal:number;
   
    @IsNumber()
    @IsNotEmpty()
    day:number;

    @IsNumber()
    @IsNotEmpty()
    reward_id:number;

}