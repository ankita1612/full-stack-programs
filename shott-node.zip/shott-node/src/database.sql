ALTER TABLE `tbl_users` ADD `login_type` ENUM('google','facebook','apple','guest','normal') NOT NULL AFTER `bind_device`;
