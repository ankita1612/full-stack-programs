import { HttpStatus, Injectable, OnModuleInit } from '@nestjs/common';
import { Chips } from './entity/chips.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { ILike, Repository } from 'typeorm';
import { logger } from 'src/logger/winston.logger';
import { ChipsDto } from './dto/chips.dto';
import { ListDto } from 'src/user/dto/list.dto';
import { log } from 'console';

@Injectable()
export class ChipsService implements OnModuleInit{
    constructor(
        @InjectRepository(Chips)
        private readonly chipsRepository: Repository<Chips>,
    ) {}


    async onModuleInit() {
       const chipsCount = await this.chipsRepository.count();
       if(chipsCount === 0){
        // Seed data
        await this.chipsRepository.save([
            {
                unit: '1',
                price: '1',
                title: '1 RS',
                currency:'INR'
            },
            {
                unit: '100',
                price: '100',
                title: '100 RS',
                currency:'INR'
            },

            {
                unit: '200',
                price: '200',
                title: '200 RS',
                currency:'INR'
            },

            {
                unit: '300',
                price: '300',
                title: '300 RS',
                currency:'INR'
            },

            {
                unit: '500',
                price: '500',
                title: '500 RS',
                currency:'INR'
            },
            {
                unit: '1000',
                price: '1000',
                title: '1000 RS',
                currency:'INR'
            },

            {
                unit: '3000',
                price: '3000',
                title: '3000 RS',
                currency:'INR'
            },

            {
                unit: '5000',
                price: '5000',
                title: '5000 RS',
                currency:'INR'
            },

            {
                unit: '10000',
                price: '10000',
                title: '10000 RS',
                currency:'INR'
            },
            {
                unit: '20000',
                price: '20000',
                title: '20000 RS',
                currency:'INR'
            },
        
        ]);
       }

    }


    async get(reqQuery:ListDto): Promise<any> {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            // Initialize where condition
            const whereCondition: any[] = [];

            // Only add conditions if search is not empty
            if (reqQuery.search) {
                const searchValue = ILike(`%${reqQuery.search}%`);
                whereCondition.push(
                    { unit:  searchValue },
                    { price: searchValue },
                    { title: searchValue },
                );
            }
             // Fetch the data using findAndCount for pagination
            const [result, count] = await this.chipsRepository.findAndCount({
                where: whereCondition.length > 0 ? whereCondition : undefined, 
                select: {
                    id: true,
                    unit: true,
                    price: true,
                    title: true,
                    created_at: true,
                },
                order: {
                    created_at: 'ASC',
                },
                take: limit,
                skip: offset,
            });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'All chips data.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
   

    async create(chipsDto:ChipsDto){
        try {
            // Await the result of the asynchronous operation
            const chipsData = await this.chipsRepository.save(chipsDto);

            // Return a custom response structure
            return {
                message: 'Chips record has been created.',
                statusCode: HttpStatus.CREATED,
                data: chipsData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }


    async update(chipsDto:ChipsDto,id:number){
        try {
            // Await the result of the asynchronous operation
            const chipsData = await this.chipsRepository.update(id,chipsDto);

            // Return a custom response structure
            return {
                message: 'Chips record has been update.',
                statusCode: HttpStatus.OK,
                data: chipsData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async delete(id:number){
        try {
            // Await the result of the asynchronous operation
            const chipsData = await this.chipsRepository.delete(id);

            // Return a custom response structure
            return {
                message: 'Chips record has been deleted.',
                statusCode: HttpStatus.OK,
                data: chipsData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}


    