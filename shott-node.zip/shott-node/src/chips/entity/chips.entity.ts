import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('chips')
export class Chips {
    @PrimaryGeneratedColumn()
    id: string;

    @Column()
    unit: string;

    @Column()
    price: string;

    @Column()
    title: string;

    @Column()
    currency: string;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
