import {
    Body,
    Controller,
    Delete,
    Get,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
    UseGuards,
} from '@nestjs/common';
import { ChipsService } from './chips.service';
import { ChipsDto } from './dto/chips.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { Permissions, Roles } from 'src/roles-permissions.decorator';
import { ListDto } from 'src/user/dto/list.dto';
import { PermissionModule } from 'src/common/enums/user.permission';
import { Role } from 'src/common/enums/role.enum';

@Controller('chips')
@UseGuards(JwtAuthGuard)
export class ChipsController {
    constructor(private readonly chipsService: ChipsService) {}

    @Get()
    async fetch(@Query() reqQuery:ListDto) {
        const record = await this.chipsService.get(reqQuery);
        return record;
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Chip)
    @Post('/create')
    async createChips(@Body() chipsDto: ChipsDto) {
        return this.chipsService.create(chipsDto);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Chip)
    @Patch('/:id')
    async updateChips(
        @Body() body: any,
        @Param('id', ParseIntPipe) id: number,
    ) {
        return this.chipsService.update(body, id);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Chip)
    @Delete('/:id')
    async deleteChips(@Param('id', ParseIntPipe) id: number) {
        return this.chipsService.delete(id);
    }
}
