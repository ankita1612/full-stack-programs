import { IsString } from "class-validator";

export class ChipsDto{
  
    @IsString()
    unit:string;

    @IsString()
    price:string;

    @IsString()
    title:string;

    @IsString()
    currency:string;
}