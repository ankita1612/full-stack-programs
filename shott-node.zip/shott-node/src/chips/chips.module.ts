import { Module } from '@nestjs/common';
import { ChipsController } from './chips.controller';
import { ChipsService } from './chips.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Chips } from './entity/chips.entity';

@Module({
  controllers: [ChipsController],
  providers: [ChipsService],
  exports:[ChipsService],
  imports:[TypeOrmModule.forFeature([Chips])]
})
export class ChipsModule {}
