export enum GameModule {
    callbreak = 'callbreak',
    rummy = 'rummy',
    teenpatti = 'teenpatti',
    ludo = 'ludo',
}