export enum PermissionModule {
    Chip = 'chips',
    Reward = 'rewards',
    User = 'users',
    Setting = 'settings',
    MasterCard = 'master-cards',
    Games = 'games',
    Avatar ='avatar',
    SubAdmin='sub-admin'
}