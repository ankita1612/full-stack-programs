import { HttpStatus, Injectable, OnModuleInit, UseGuards } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { logger } from "src/logger/winston.logger";
import { Repository } from "typeorm";
import { ModuleEntity } from "../entity/module.entity";
import { GameModule } from "../enums/game.enum";
import { PermissionModule } from "../enums/user.permission";


@Injectable()

export class CommonService implements OnModuleInit{
    constructor(
        @InjectRepository(ModuleEntity)
        private readonly moduleRepository: Repository<ModuleEntity>,

    ){}

    async onModuleInit() {
          // Fetch existing permissions from the database
        const existingModules = await this.moduleRepository.find();
        const existingModuleNames = existingModules.map(module => module.name);

        // Define permissions based on your enum
        const allPermissions = [
            PermissionModule.Chip,
            PermissionModule.Reward,
            PermissionModule.User,
            PermissionModule.MasterCard,
            PermissionModule.Games,
            PermissionModule.Avatar
        ];

        // Filter out permissions that are already in the database
        const newPermissions = allPermissions.filter(permission => !existingModuleNames.includes(permission));

        // If there are new permissions, insert them
        if (newPermissions.length > 0) {
            const modulesToInsert = newPermissions.map(permission => ({ name: permission }));
            await this.moduleRepository.save(modulesToInsert);
        }
    }

    /**fetch module **/
    async fetchModules() {
        try {
            const module = await this.moduleRepository.find();
            return {
                message: 'All modules list.',
                statusCode: HttpStatus.OK,
                data: module || [],
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

   
}