import { HttpStatus, Injectable } from '@nestjs/common';
import { error, log } from 'console';
import { Response, Request } from 'express';
import * as fastcsv from 'fast-csv';
import * as fs from 'fs';
import * as path from 'path';


@Injectable()
export class CsvExportService {
    
    async exportCsv(req: Request, res: Response, data: any[], headers: string[], filename: string) {
        const filePath = path.join('public/csv',`${filename}.csv`);
        console.log(filePath);
        try {
            // Create the directory if it doesn't exist
            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            // Create a write stream
            const ws = fs.createWriteStream(filePath);
            fastcsv
                .write(data, { headers })
                .pipe(ws)
                .on('finish', () => {
                    console.log('CSV export completed successfully.');
                    const fullUrl = `${req.protocol}://${req.headers.host}/csv/${filename}.csv`;
                    res.status(200).json({ 
                        error:false,
                        statusCode: HttpStatus.OK,
                        messageCode:'OK',
                        message: 'CSV generated successfully.',
                        data: {url:fullUrl} 
                        });
                })
                .on('error', (err) => {
                    console.error('Error exporting CSV:', err);
                    res.status(500).json({ 
                        error:true,
                        statusCode: HttpStatus.BAD_REQUEST,
                        message:['Error exporting CSV.'],
                        messageCode:'BAD_REQUEST',
                        errorMessage: ['Error exporting CSV.'],
                        });
                });
        } catch (error) {
            console.error('Unexpected error during CSV export:', error);
            res.status(500).send('Unexpected error during CSV export');
        }
    }
}