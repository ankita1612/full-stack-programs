// common.module.ts
import { Module } from '@nestjs/common';
import { CommonController } from './controller/common.controller';
import { CommonService } from './services/common.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ModuleEntity } from './entity/module.entity';


@Module({
  imports:[TypeOrmModule.forFeature([
    ModuleEntity
]),],
  controllers: [CommonController],
  providers: [CommonService],
})
export class CommonModule {}
