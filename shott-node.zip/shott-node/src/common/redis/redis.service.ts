import { Injectable } from '@nestjs/common';
import { RedisClientType, createClient } from 'redis';

@Injectable()
export class RedisService {
    private client: RedisClientType;

    constructor() {
        this.client = createClient({ url: 'redis://localhost:6379' });
        this.client.connect();
    }

    async addUserToRoom(
        game: string,
        roomId: string,
        userId: number,
    ): Promise<void> {
        const room = await this.client.hGet(game, roomId);
        const parsedRoom = room ? JSON.parse(room) : { users: [] };
        parsedRoom.users = [...new Set(parsedRoom.users), userId];
        await this.client.hSet(game, roomId, JSON.stringify(parsedRoom));
        return;
    }

    async removeUserToRoom(
        game: string,
        roomId: string,
        userId: number,
    ): Promise<void> {
        const room = await this.client.hGet(game, roomId);
        const parsedRoom = room ? JSON.parse(room) : { users: [] };
        parsedRoom.users = [...new Set(parsedRoom.users)];
        parsedRoom.users = parsedRoom.users.filter(
            (item: number) => item !== userId,
        );

        await this.client.hSet(game, roomId, JSON.stringify(parsedRoom));
        return;
    }

    async getRoomPlayers(game: string, roomId: string) {
        const room = await this.client.hGet(game, roomId);
        const parsedRoom = room ? JSON.parse(room) : { users: [] };
        return [...new Set(parsedRoom.users)];
    }

    async deleteRoom(game: string, roomId: string): Promise<void> {
        await this.client.hDel(game, roomId);
    }

    async deleteAllRooms(game: string): Promise<void> {
        await this.client.del(game); // Deletes the entire hash for the game
    }

    async getAllRooms(game: string) {
        const rooms = await this.client.hGetAll(game);
        const parsedRooms = {};

        // Parse each room's data from JSON format
        for (const [roomId, roomData] of Object.entries(rooms)) {
            parsedRooms[roomId] = JSON.parse(roomData);
        }

        return parsedRooms;
    }
}
