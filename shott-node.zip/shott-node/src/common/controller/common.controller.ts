import { Controller, Get, UseGuards } from "@nestjs/common";
import { Permissions, Roles } from "src/roles-permissions.decorator";
import { RoleAndPermissionGuard } from "src/roles-permissions.guard";
import { Role } from "../enums/role.enum";
import { PermissionModule } from "../enums/user.permission";
import { JwtAuthGuard } from "src/auth/jwt-auth.guard";
import { CommonService } from "../services/common.service";

@Controller('common')
@UseGuards(JwtAuthGuard)
export class CommonController {
    constructor(
        private readonly commonService: CommonService
    ) {}


    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin,Role.SubAdmin)
    @Permissions(PermissionModule.Setting)
    @Get('/module/list')
    async moduleList() {
        const record = await this.commonService.fetchModules();
        return record;
    }

}
