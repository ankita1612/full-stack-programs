import { Queue } from 'bull';
import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';

@Injectable()
export class QueueService {
    constructor(
        // @InjectQueue('ludoQueue') private readonly ludoQueue: Queue,
        // @InjectQueue('tinpatiQueue') private readonly tinpatiQueue: Queue,
        @InjectQueue('callbreakQueue') private readonly callbreakQueue: Queue,
    ) {}

    async addToQueue(
        queueName: string,
        jobName: string,
        data: any,
    ): Promise<void> {
        if (queueName === 'ludoQueue') {
            //   await this.ludoQueue.add(jobName, data);
        } else if (queueName === 'tinpatiQueue') {
            //   await this.tinpatiQueue.add(jobName, data);
        } else if (queueName === 'callbreakQueue') {
            this.callbreakQueue.add(jobName, data);

            /*
             * FETCH JOB STATUS TO CONSOLE getJobCounts
             const jobCounts = await this.callbreakQueue.getJobCounts(); 
              {
                waiting: 0,
                active: 0,
                completed: 1000,
                failed: 0,
                delayed: 0,
                paused: 0
              }
            */
        }
    }
}
