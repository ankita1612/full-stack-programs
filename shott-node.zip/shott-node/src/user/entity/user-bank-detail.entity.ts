import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    OneToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { User } from './user.entity';

@Entity('user_bank_details')
export class UserBankDetail {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user_id: number;

    @Column()
    bank_name: string;

    @Column()
    account_number: string;

    @Column()
    holder_name: string;

    @Column()
    ifsc_code: string;

    @OneToOne(() => User, (user) => user.bank_detail, { onDelete: 'CASCADE' }) // One-to-one relationship
    @JoinColumn({ name: 'user_id' }) // Foreign key
    user: User;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
