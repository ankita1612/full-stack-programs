import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    OneToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { User } from './user.entity';

export enum KycStatus {
    PENDING = 'Pending',
    APPROVED = 'Approved',
    REJECT = 'Reject',
}

@Entity('user_kyc_details')
export class UserKycDetail {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user_id: number;

    @Column({ default: '' })
    pan_card: string;

    @Column({ default: '' })
    adhar_card: string;

    @OneToOne(() => User, (user) => user.bank_detail, { onDelete: 'CASCADE' }) // One-to-one relationship
    @JoinColumn({ name: 'user_id' }) // Foreign key
    user: User;

    @Column({ type: 'enum', enum: KycStatus, default: KycStatus.PENDING })
    status: string;

    @Column({ default: '' })
    reject_reason: string;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
