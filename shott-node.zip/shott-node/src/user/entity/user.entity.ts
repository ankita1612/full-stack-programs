import {
    Column,
    CreateDateColumn,
    Entity,
    OneToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { UserBankDetail } from './user-bank-detail.entity';
import { Role } from 'src/common/enums/role.enum';
import { CallbreakRooms } from 'src/callbreaks/entities/callbreak-rooms.entity';
@Entity('users')
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ default: '' })
    name: string;

    @Column({ type: 'enum', enum: Role })
    role: string;

    @Column({ type: 'json' }) // store permissions as a string array
    permissions: string[];

    @Column({ type: 'int', width: 11, default: 0 })
    total_played_games: number;

    @Column({ type: 'int', width: 11, default: 0 })
    total_win_games: number;

    @Column({ default: false })
    is_online: boolean;

    @Column({ default: '' })
    email: string;

    @Column({ default: '' })
    mobile: string;

    @Column({ default: '' })
    password: string;

    @Column({ default: '' })
    last_claim_day: string;

    @Column({ default: '' })
    profile_pic: string;

    @Column({ default: '' })
    referral_code: string;

    @Column({ default: '' })
    referred_by: string;

    @Column({ default: 0, type: 'double' })
    wallet: number;

    @Column({ default: 0, type: 'double' })
    unutilized_wallet: number;

    @Column({ default: 0, type: 'double' })
    winning_wallet: number;

    @Column({ default: 0, type: 'double' })
    bonus_wallet: number;

    @Column({ default: '' })
    fcm: string;

    @Column({ default: 1, type: 'int' })
    status: number;

    @Column({ default: false })
    is_kyc_verified: boolean;

    @Column({ default: false })
    is_completed_profile: boolean;

    @Column({ default: 'normal' }) // 'guest','normal'
    login_type: string;

    @Column({ default: false })
    is_otp_verified: boolean;

    @Column({ default: '' })
    otp: string;

    @Column({ type: 'timestamp' })
    otp_sent_time: Date;

    @Column({ default: 0})
    coins: number;

    @OneToOne(() => UserBankDetail, (bankDetail) => bankDetail.user, {
        nullable: true,
    }) // Nullable, because not all users will have bank details
    bank_detail: UserBankDetail;

    @Column({ default:0})
    callbreak_room_id:number;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
