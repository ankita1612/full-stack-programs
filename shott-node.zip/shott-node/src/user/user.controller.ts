import {
    Body,
    Controller,
    Delete,
    Get,
    HttpException,
    HttpStatus,
    Param,
    ParseIntPipe,
    Patch,
    Post,
    Put,
    Query,
    Req,
    Res,
    UploadedFile,
    UploadedFiles,
    UseGuards,
    UseInterceptors,
} from '@nestjs/common';
import { UserService } from './user.service';
import { UpdateUserDto } from './dto/update-user.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import {
    FileFieldsInterceptor,
    FileInterceptor,
} from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import * as fs from 'fs';
import { UpdateUserBankDetailDto } from './dto/update-user-bank-detail.dto';
import { Roles, Permissions } from 'src/roles-permissions.decorator';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { ListDto } from './dto/list.dto';
import { UpdateUserKycDetailDto } from './dto/update-user-kyc-detail.dto';
import { CsvExportService } from 'src/common/services/csv-export.service';
import { Response,Request} from 'express';
import { extname } from 'path';
import { CreateUserDto } from './dto/create-user.dto';
import { json } from 'stream/consumers';
import { CreateAdminDto } from './dto/create-admin.dto';
import { PermissionModule } from 'src/common/enums/user.permission';
import { Role } from 'src/common/enums/role.enum';
import { UpdateStatusDto } from './dto/update-status.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

@Controller('user')
@UseGuards(JwtAuthGuard)
export class UserController {
    //------- CONSTRUCTOR

    constructor(
        private userService: UserService,
        private readonly csvExportService: CsvExportService
    ) {}
    

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.User)
    @Get('/list')
    async getUsers(@Query() reqQuery: ListDto) {
        return await this.userService.getUserList(reqQuery);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.User)
    @Patch('')
    @UseInterceptors(
        FileInterceptor('profile_pic', {
            storage: diskStorage({
                destination: 'public/user/profile',
                filename: (req, file, cb) => {
                    const uniqueSuffix =
                        Date.now() + '-' + Math.round(Math.random() * 1e9);
                    const nameTab = file.originalname.split('.');
                    const subArray = nameTab.slice(0, -1);
                    const originalName = subArray.join('');
                    const ext = `.${nameTab[nameTab.length - 1]}`;
                    const filename = `${originalName}-${uniqueSuffix}${ext}`;
                    cb(null, filename);
                },
            }),
        }),
    )
    async update(
        @Req() req,
        @Body() UpdateUserDto: Partial<UpdateUserDto>,
        @UploadedFile() file: Express.Multer.File,
    ) {
        if (file) {
            UpdateUserDto.profile_pic = file.path;
        } else if (UpdateUserDto.avatar) {
            UpdateUserDto.profile_pic = UpdateUserDto.avatar;
        }

        delete UpdateUserDto.avatar;

        return await this.userService.update(
            { ...UpdateUserDto, is_completed_profile: true },
            req.user.id,
        );
    }

    @Get('')
    async getUser(@Req() req) {
        return await this.userService.findOneById(req.user.id);
    }

    @Delete('')
    async deleteUser(@Req() req) {
        return await this.userService.delete(req?.user.id);
    }

    //--------- BANK DETAILS --------------------

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.User)
    @Patch('bank-detail')
    async updateBankDetail(
        @Req() req,
        @Body() updateUserBankDetailDto: UpdateUserBankDetailDto,
    ) {
        return await this.userService.updateBankDetail(
            updateUserBankDetailDto,
            req.user.id,
        );
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Get('/bank-detail-list')
    async getBankDetailList(@Query() reqQuery: ListDto) {
        return await this.userService.getBankDetailList(reqQuery);
    }

    //--------- KYC DETAILS ----------------

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.User)
    @Patch('kyc')
    @UseInterceptors(
        FileFieldsInterceptor(
            [
                { name: 'adhar_card', maxCount: 1 },
                { name: 'pan_card', maxCount: 1 },
            ],
            {
                storage: diskStorage({
                    destination: (req, file, cb) => {
                        let uploadPath = 'public/user/kyc';

                        // Store Aadhaar in 'kyc/adhar' and PAN in 'kyc/pan'
                        if (file.fieldname === 'adhar_card') {
                            uploadPath = 'public/user/kyc/adhar';
                        } else if (file.fieldname === 'pan_card') {
                            uploadPath = 'public/user/kyc/pan';
                        }
                        if (!fs.existsSync(uploadPath)) {
                            fs.mkdirSync(uploadPath, { recursive: true });
                        }

                        cb(null, uploadPath);
                    },
                    filename: (req, file, cb) => {
                        const uniqueSuffix =
                            Date.now() + '-' + Math.round(Math.random() * 1e9);
                        const ext = extname(file.originalname);
                        const filename = `${file.fieldname}-${uniqueSuffix}${ext}`;
                        cb(null, filename);
                    },
                }),
            },
        ),
    )
    async updateKyc(
        @Req() req,
        @Body() updateKycDto: Partial<UpdateUserKycDetailDto>,
        @UploadedFiles()
        files: {
            adhar_card?: Express.Multer.File[];
            pan_card?: Express.Multer.File[];
        },
    ) {
        let kyc_changed: boolean = false;

        if (files?.adhar_card && files?.adhar_card?.length > 0) {
            kyc_changed = true;
            updateKycDto.adhar_card = files?.adhar_card[0].path; // Store the path for Aadhaar
        }
        if (files?.pan_card && files?.pan_card?.length > 0) {
            kyc_changed = true;
            updateKycDto.pan_card = files.pan_card[0]?.path; // Store the path for PAN
        }

        if (!updateKycDto?.adhar_card && !updateKycDto?.pan_card) {
            throw new HttpException(
                'Please provide valid kyc details.',
                HttpStatus.BAD_REQUEST,
            );
        }

        // Proceed with updating the user with KYC information

        return await this.userService.updateUserKyc(
            updateKycDto,
            req.user.id,
            kyc_changed,
        );
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Patch('/kyc/status/:id')
    async updateKycStatus(
        @Param('id') id: string,
        @Body() updateKycDto: Partial<UpdateUserKycDetailDto>,
    ) {
        // Proceed with updating the user with KYC information
        return await this.userService.updateUserKycStatus(+id, updateKycDto);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.User)
    @Get('/kyc-list')
    async getKycList(@Query() reqQuery: ListDto) {
        return await this.userService.getKycList(reqQuery);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.User)
    @Get('/export')

        async exportUsers(@Res() res: Response, @Req() req: Request) {
        const users = await this.userService.getAllUsers();
        const formattedUsers = users.map(user => ({
            ID: user.id,
            Name: user.name,
            Email: user.email,
            Mobile: user.mobile,
            Wallet:user.wallet,
            KYC_Verified: user.is_kyc_verified===true?'Yes':'No',
            }));
            const headers = ['ID', 'Name', 'Email','Mobile','Wallet','KYC Verified'];
    
        await this.csvExportService.exportCsv(req, res, formattedUsers, headers, 'users');
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Post('/add')
    async addUsers( 
    @Req() req,
    @Body() createUserDto: CreateUserDto) {
        const users = await this.userService.createUsers(createUserDto);
        return users;
       
    }
    @UseInterceptors(
        FileInterceptor('profile_pic', {
            storage: diskStorage({
                destination: 'public/user/profile',
                filename: (req, file, cb) => {
                    const uniqueSuffix =
                        Date.now() + '-' + Math.round(Math.random() * 1e9);
                    const nameTab = file.originalname.split('.');
                    const subArray = nameTab.slice(0, -1);
                    const originalName = subArray.join('');
                    const ext = `.${nameTab[nameTab.length - 1]}`;
                    const filename = `${originalName}-${uniqueSuffix}${ext}`;
                    cb(null, filename);
                },
            }),
        }),
    )

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.SubAdmin)
    @Post('/add/sub-admin')
    async addSubAdmin(
        @Req() req: Request,
        @Body() createAdminDto: CreateAdminDto,
        @UploadedFile() file: Express.Multer.File
    ) {
            if (file) {
                createAdminDto.profile_pic = file.path;
            }
            // // Ensure permissions is provided
            if (!createAdminDto.permissions || createAdminDto.permissions.length === 0) {
                throw new HttpException(
                    'Permissions must be provided',
                    HttpStatus.BAD_REQUEST,
                );
            }
            // Create the user with 'sub-admin' type and save permissions as array
            const users = await this.userService.createAdminUsers(createAdminDto);
            return users;
    }
   
    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.SubAdmin)
    @Patch('/block/:id')
    async blockUser(
        @Param('id',ParseIntPipe) id: number,
        @Body() updateStatusDto:UpdateStatusDto,
    )
    {
      const user = await this.userService.blockUsers(id,updateStatusDto)
      return user;
    }
    

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.SubAdmin)
    @Patch('/update/sub-admin')
    @UseInterceptors(
        FileInterceptor('profile_pic', {
            storage: diskStorage({
                destination: 'public/user/profile',
                filename: (req, file, cb) => {
                    const uniqueSuffix =
                        Date.now() + '-' + Math.round(Math.random() * 1e9);
                    const nameTab = file.originalname.split('.');
                    const subArray = nameTab.slice(0, -1);
                    const originalName = subArray.join('');
                    const ext = `.${nameTab[nameTab.length - 1]}`;
                    const filename = `${originalName}-${uniqueSuffix}${ext}`;
                    cb(null, filename);
                },
            }),
        }),
    )
    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.SubAdmin)
    async updateSubAdmin(
        @Req() req,
        @Body() createAdminDto: CreateAdminDto,
        @UploadedFile() file: Express.Multer.File
    ) {
            if (!createAdminDto.permissions || createAdminDto.permissions.length === 0) {
                throw new HttpException(
                    'Permissions must be provided',
                    HttpStatus.BAD_REQUEST,
                );
            }
            // Update the user with 'sub-admin' type and save permissions as array
            const users = await this.userService.updateAdminUsers(createAdminDto);
            return users;
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Put('change/password')
    async changePassword(
        @Req() req,
        @Body() changePasswordDto: ChangePasswordDto,
    ) {
        return this.userService.changePassword(req.user.id, changePasswordDto);
    }
}
