import * as bcryptjs from 'bcryptjs';
import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { UpdateUserDto } from './dto/update-user.dto';
import { ILike, In, IsNull, Not, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { logger } from 'src/logger/winston.logger';
import { Setting } from 'src/settings/entity/setting.entity';
import { UserBankDetail } from './entity/user-bank-detail.entity';
import { LoginDto } from 'src/auth/dto/login.dto';
import { UpdateUserBankDetailDto } from './dto/update-user-bank-detail.dto';
import { ListDto } from './dto/list.dto';
import { KycStatus, UserKycDetail } from './entity/user-kyc-detail.entity';
import { UpdateUserKycDetailDto } from './dto/update-user-kyc-detail.dto';
import { CreateUserDto } from './dto/create-user.dto';
import { CreateAdminDto } from './dto/create-admin.dto';
import { Role } from 'src/common/enums/role.enum';
import { User } from './entity/user.entity';
import { PermissionModule } from 'src/common/enums/user.permission';
import { UpdateStatusDto } from './dto/update-status.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

@Injectable()
export class UserService {
    constructor(
        @InjectRepository(User)
        private userRepository: Repository<User>,
        @InjectRepository(UserBankDetail)
        private userBankRepository: Repository<UserBankDetail>,
        @InjectRepository(UserKycDetail)
        private userKycRepository: Repository<UserKycDetail>,
        @InjectRepository(Setting)
        private settingRepository: Repository<Setting>,
    ) {}

    async onModuleInit() {
        const admin = await this.userRepository.count({
            where: {
                role: Role.Admin,
            },
        });
        if (admin === 0) {
            // Seed data
            await this.userRepository.save({
                name: 'super admin',
                email: 'super.admin@shott.com',
                password: await bcryptjs.hash('Test@123', 10), //'Test@123'
                role: Role.Admin,
                permissions: [
                    PermissionModule.Chip,
                    PermissionModule.Reward,
                    PermissionModule.Setting,
                    PermissionModule.User,
                    PermissionModule.MasterCard,
                    PermissionModule.Games,
                    PermissionModule.Avatar,
                    PermissionModule.SubAdmin,
                ],
                otp_sent_time: new Date(),
            });
        }

        const subAdmin = await this.userRepository.count({
            where: {
                role: Role.SubAdmin,
            },
        });

        if (subAdmin === 0) {
            // Seed data
            await this.userRepository.save({
                name: 'sub admin',
                email: 'sub.admin@shott.com',
                password: await bcryptjs.hash('Test@123', 10), //'Test@123'
                role: Role.SubAdmin,
                permissions: [
                    PermissionModule.Chip,
                    PermissionModule.Reward,
                    PermissionModule.Setting,
                    PermissionModule.User,
                    PermissionModule.MasterCard,
                    PermissionModule.Games,
                    PermissionModule.Avatar,
                ],
                otp_sent_time: new Date(),
            });
        }
    }

    async create(loginDto: LoginDto): Promise<User> {
        try {
            return await this.userRepository.save({
                ...loginDto,
                otp_sent_time: new Date(),
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async update(
        UpdateUserDto: Partial<UpdateUserDto>,
        userId: number,
    ): Promise<User> {
        try {
            delete UpdateUserDto.mobile;

            if (UpdateUserDto.mobile) {
                throw new HttpException(
                    'Mobile number could not be updated.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (UpdateUserDto.referred_by) {
                const validReferralCode = await this.findOne({
                    referral_code: UpdateUserDto.referred_by,
                    role:Role.User,
                    status:'1',
                });
                // Await the user repository findOne promise
                const user = await this.userRepository.findOne({
                    where: { id: userId },
                });
                // Log after awaiting
                if (!validReferralCode || user.referred_by) {
                    throw new HttpException(
                        'Invalid Referral code',
                        HttpStatus.BAD_REQUEST,
                    );
                }
                UpdateUserDto.referred_by = validReferralCode
                    ? validReferralCode?.id?.toString()
                    : '';
            }

            await this.userRepository.update(userId, UpdateUserDto);
            return this.userRepository.findOne({
                where: { id: userId },
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findOneById(id: number): Promise<User> {
        try {
            return this.userRepository.findOne({
                where: { id },
                relations: ['bank_detail'],
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async getUserList(reqQuery: ListDto) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            let role = Role.User;
            if (reqQuery.type == 'sub admin') {
               role = Role.SubAdmin;
            }
            const [result, count] = await this.userRepository.findAndCount({
                where: [
                    {
                        role: role,
                        name: ILike(`%${reqQuery.search}%`),
                    },
                    {
                        role: role,
                        mobile: ILike(`%${reqQuery.search}%`),
                    },
                ],
                select: {
                    id: true,
                    name: true,
                    total_played_games: true,
                    total_win_games: true,
                    is_online: true,
                    email: true,
                    mobile: true,
                    profile_pic: true,
                    referral_code: true,
                    wallet: true,
                    permissions:true,
                    unutilized_wallet: true,
                    winning_wallet: true,
                    bonus_wallet: true,
                    status: true,
                    is_kyc_verified: true,
                    is_completed_profile: true,
                    created_at: true,
                },
                order: {
                    created_at: 'DESC',
                },
                take: limit,
                skip: offset,
            });
                    // Process the permissions field
                const transformedResult = result.map(user => {
                    if (Array.isArray(user.permissions)) {
                        const permissionsArray = user.permissions.map(permission => ({
                            label: permission ?.trim(),
                            value: permission ?.trim(),
                        }));
                        return {
                            ...user,
                            permissions: permissionsArray,
                        };
                    }
                    return user;
                });
            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'Users fetched successfully.',
                data: {
                    docs: transformedResult,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findOne(payload: any): Promise<User> {
        try {
            return await this.userRepository.findOne({ where: payload });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findByEmail(email: string): Promise<User> {
        try {
            return this.userRepository.findOne({ where: { email } });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findByMobile(mobile: string): Promise<any> {
        try {
            return this.userRepository.findOne({ where: { mobile } });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async delete(userId: number): Promise<User> {
        try {
            await this.userRepository.update(userId, { status: 0 });
            return this.userRepository.findOne({ where: { id: userId } });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async generateReferralCode(userId: number): Promise<string> {
        try {
            const settings = await this.settingRepository.findOne({
                where: {},
                select: ['referral_prefix'],
            });
            return `${settings.referral_prefix ? settings.referral_prefix : 'SHOTT_'}${userId}`;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async generateOneTimePassword(length: number): Promise<string> {
        try {
            const digits = '0123456789';
            let otp = '';

            for (let i = 0; i < length; i++) {
                const randomIndex = Math.floor(Math.random() * digits.length);
                otp += digits[randomIndex];
            }

            // return otp;
            return '0000'; // For testing purposes
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    //------------------------ BANK DETAILS ------------------------

    async findOneUserBankAccount(userId: number): Promise<UserBankDetail> {
        try {
            return await this.userBankRepository.findOne({
                where: { user_id: userId },
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async updateBankDetail(
        updateUserBankDetailDto: UpdateUserBankDetailDto,
        userId: number,
    ): Promise<UserBankDetail> {
        try {
            const userBankDetail = await this.findOneUserBankAccount(userId);

            if (userBankDetail) {
                await this.userBankRepository.update(
                    userBankDetail.id,
                    updateUserBankDetailDto,
                );
            } else {
                await this.userBankRepository.save({
                    ...updateUserBankDetailDto,
                    user_id: userId,
                });
            }

            return await this.findOneUserBankAccount(userId);
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async getBankDetailList(reqQuery: ListDto) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            const [result, count] = await this.userBankRepository.findAndCount({
                where: [
                    { bank_name: ILike(`%${reqQuery.search}%`) },
                    { account_number: ILike(`%${reqQuery.search}%`) },
                    { holder_name: ILike(`%${reqQuery.search}%`) },
                    { ifsc_code: ILike(`%${reqQuery.search}%`) },
                    {
                        user: {
                            name: ILike(`%${reqQuery.search}%`),
                        },
                    },
                ],
                relations: ['user'],
                select: {
                    id: true,
                    bank_name: true,
                    account_number: true,
                    holder_name: true,
                    ifsc_code: true,
                    created_at: true,
                    user: { id: true, name: true },
                },
                order: {
                    created_at: 'DESC',
                },
                take: limit,
                skip: offset,
            });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'Bank details fetched successfully.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    //------------------------ KYC DETAILS ------------------------

    async findOneUserKycByUserId(user_id: number): Promise<UserKycDetail> {
        try {
            return await this.userKycRepository.findOne({
                where: { user_id },
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    async findOneUserKyc(id: number): Promise<UserKycDetail> {
        try {
            return await this.userKycRepository.findOne({
                where: { id },
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async updateUserKyc(
        UpdateUserKycDto: Partial<UpdateUserKycDetailDto>,
        userId: number,
        kyc_changed: boolean,
    ): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: UserKycDetail;
    }> {
        try {
            const userKycExist = await this.findOneUserKycByUserId(userId);

            //---- change kyc status if user has changed documents
            if (kyc_changed) {
                await this.userRepository.update(userId, {
                    is_kyc_verified: false,
                });
            }

            if (!userKycExist) {
                await this.userKycRepository.save({
                    ...UpdateUserKycDto,
                    user_id: userId,
                });
            } else {
                const update = await this.userKycRepository.update(
                    userKycExist.id,
                    UpdateUserKycDto,
                );
            }

            const userKycDetail = await this.findOneUserKycByUserId(userId);

            return {
                statusCode: HttpStatus.CREATED,
                message: 'Kyc details has been updated successfully.',
                data: userKycDetail,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async updateUserKycStatus(
        id: number,
        UpdateUserKycDto: Partial<UpdateUserKycDetailDto>,
    ): Promise<{
        statusCode: HttpStatus;
        message: string;
        data: UserKycDetail;
    }> {
        try {
            const userKycExist = await this.findOneUserKyc(id);

            if (!userKycExist) {
                throw new HttpException(
                    'Kyc details not found',
                    HttpStatus.NOT_FOUND,
                );
            }

            if (
                ![
                    KycStatus.APPROVED.toString(),
                    KycStatus.REJECT.toString(),
                ].includes(UpdateUserKycDto.status)
            ) {
                throw new HttpException(
                    'Please provide valid status.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (
                KycStatus.REJECT.toString() == UpdateUserKycDto.status &&
                !UpdateUserKycDto.reject_reason
            ) {
                throw new HttpException(
                    'Please provide valid rejection reason.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            if (KycStatus.REJECT.toString() == UpdateUserKycDto.status) {
                await this.userRepository.update(userKycExist.user_id, {
                    is_kyc_verified: false,
                });
            }

            await this.userKycRepository.update(userKycExist.id, {
                status: UpdateUserKycDto.status,
                reject_reason: UpdateUserKycDto?.reject_reason
                    ? UpdateUserKycDto?.reject_reason
                    : '',
            });

            const userKycDetail = await this.findOneUserKyc(id);

            return {
                statusCode: HttpStatus.CREATED,
                message: 'Kyc status has been updated successfully.',
                data: userKycDetail,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async getKycList(reqQuery: ListDto) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            const [result, count] = await this.userKycRepository.findAndCount({
                where: {
                    status: reqQuery.status
                        ? reqQuery.status
                        : KycStatus.PENDING,
                    user: {
                        name: ILike(`%${reqQuery.search}%`),
                    },
                },
                relations: ['user'],
                select: {
                    id: true,
                    adhar_card: true,
                    pan_card: true,
                    user_id: true,
                    status: true,
                    reject_reason: true,
                    created_at: true,
                    user: { name: true },
                },
                order: {
                    created_at: 'DESC',
                },
                take: limit,
                skip: offset,
            });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'Kyc details fetched successfully.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    /**Fetch all users**/ 
    async getAllUsers(): Promise<User[]> {
        try {
            return await this.userRepository.find(); 
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

     /**create users for admin **/
     async createUsers(createUserDto:CreateUserDto){
        try {
          const userExist = await this.getUserByMobile(createUserDto.mobile);
            if (userExist) {
                throw new HttpException(
                    'User already Exist.', 
                    HttpStatus.BAD_REQUEST
                )
            }
            createUserDto.permissions = createUserDto.permissions || [];
            
            const userData = await this.userRepository.save({
                ...createUserDto,
                otp_sent_time : new Date()
            });

            return {
                statusCode: HttpStatus.CREATED,
                message: 'User has been created.',
                data: userData,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**find  users from mobile number **/
    async getUserByMobile(mobile:string)
    {
        try {
            return await this.userRepository.findOne({ 
                where: { 
                    mobile: mobile,
                } 
            });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

     /**find duplicate users from admin side **/
     async getUserByEmail(id: number, email: string)
     {
         try {
            if(id > 0){
           
                return await this.userRepository.findOne({ 
                    where: { 
                        id: Not(id),
                       email: email,
                    } 
                });

            }
             return await this.userRepository.findOne({ 
                 where: { 
                    email: email,
                 } 
             });
         } catch (error) {
             logger.error(error);
             throw error;
         }
     }

     async createAdminUsers(createAdminDto: CreateAdminDto) {
        try {
            // Check if user with the same email already exists
            const userExist = await this.getUserByEmail(0,createAdminDto.email);
            if (userExist) {
                throw new HttpException(
                    'User already exists.',
                    HttpStatus.BAD_REQUEST
                );
            }
    
            // Save the user data to the database
            const userData = await this.userRepository.save({
                ...createAdminDto,
                password: await bcryptjs.hash(createAdminDto.password, 10),
                otp_sent_time: new Date(),
                role:'sub admin'
            });
    
            return {
                statusCode: HttpStatus.CREATED,
                message: 'Sub admin has been created.',
                data: userData,
            };
        } catch (error) {
            logger.error(error);
            throw error; 
        }
    }
    /**updated coins */
    async updateCoins(userId: number, coins: number, type=false): Promise<User> {
        // Find the user by ID
        const user = await this.userRepository.findOne({ where: { id: userId } });
    
        if (!user) {
          throw new Error('User not found');
        }
        if(type==true){
            user.coins =user.coins-coins; 
        }else{
            user.coins += coins; 
        }

        // Save the updated user
        await this.userRepository.save(user);
    
        return user;  // Return updated user object
      }
      /**update user sub admin */
      async updateAdminUsers(createAdminDto: CreateAdminDto) {
        try {
            const id = Number(createAdminDto.id);
            // Check if user with the same email already exists
            const userExist = await this.getUserByEmail(id,createAdminDto.email);
            if (userExist) {
                throw new HttpException(
                    'User already exists.',
                    HttpStatus.BAD_REQUEST
                );
            }
    
            // Save the user data to the database
            const userData = await this.userRepository.update(
                { id },
                {
                ...createAdminDto,
                otp_sent_time: new Date(),
                role:'sub admin'
                }
        );
    
            return {
                statusCode: HttpStatus.OK,
                message: 'Sub admin has been updated.',
                data: userData,
            };
        } catch (error) {
            logger.error(error);
            throw error; 
        }
    }

    /**block user */
    async blockUsers(id:number,updateStatusDto: UpdateStatusDto) {
        try {
            const user = await this.userRepository.findOne({ 
                where: {
                    id: id,
                    role: In([Role.User,Role.SubAdmin]),
                  }, 
            });
            if(!user){
                throw new HttpException(
                    'Invalid user id.',
                    HttpStatus.BAD_REQUEST
                );
            }
            const userData =  await this.userRepository.update(id, { status: updateStatusDto.status });
            return {
                statusCode: HttpStatus.OK,
                message: 'User status has been changed.',
                data: userData,
            };
        } catch (error) {
            logger.error(error);
            throw error; 
        }
    }
    async updatePassword(id: number, hashedPassword: string) {
        return this.userRepository.update(id, { password: hashedPassword });
      }
    /**change password */
    async changePassword(id:number,changePasswordDto: ChangePasswordDto)
    {
        try {
            const { current_password, new_password, confirm_password } = changePasswordDto;

            const user =  await this.userRepository.findOne({ 
                where: {
                    id: id,
                    role: In([Role.User,Role.SubAdmin]),
                  }, 
            });
            if(!user){
                throw new HttpException(
                    'Invalid user id.',
                    HttpStatus.BAD_REQUEST
                );
            }
        
            const isMatch = await bcryptjs.compare(current_password, user.password);
            if (!isMatch) {
                throw new HttpException(
                    'Current password is incorrect.',
                    HttpStatus.BAD_REQUEST
                );
            }
        
            if (new_password !== confirm_password) {
                throw new HttpException(
                    'New password and confirmation do not match.',
                    HttpStatus.BAD_REQUEST
                );
            }
        
            const hashedNewPassword = await bcryptjs.hash(new_password, 10);
            await this.updatePassword(id, hashedNewPassword);
        
            return {
                statusCode: HttpStatus.OK,
                message: 'Password successfully updated.',
                data: {},
            };
        } catch (error) {
            logger.error(error)
            throw error;
        }
    }
    
    async updateCallBreakRoomId(userId: number[], data: Partial<User>) {
        try {
            await this.userRepository.update(userId, data);
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    
}
