import { Module } from '@nestjs/common';
import { UserController } from './user.controller';
import { UserService } from './user.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entity/user.entity';
import { UserBankDetail } from './entity/user-bank-detail.entity';
import { UserKycDetail } from './entity/user-kyc-detail.entity';
import { CsvExportService } from 'src/common/services/csv-export.service';

@Module({
    controllers: [UserController],
    providers: [UserService,CsvExportService],
    exports: [UserService],
    imports: [
        TypeOrmModule.forFeature([
            User,
            UserBankDetail,
            UserKycDetail,
        ]),
    ],
})
export class UserModule {}
