import { IsString, MinLength, Matches, IsNotEmpty, ValidateIf, ValidatorConstraint, ValidatorConstraintInterface, ValidationArguments, Validate } from 'class-validator';


@ValidatorConstraint({ name: 'PasswordMatch', async: false })

export class PasswordMatch implements ValidatorConstraintInterface {
  validate(confirm_password: string, args: ValidationArguments) {
    const [relatedPropertyName] = args.constraints;
    const newPassword = (args.object as any)[relatedPropertyName];
    return confirm_password === newPassword;
  }

  defaultMessage(args: ValidationArguments) {
    return 'Passwords do not match.';
  }
}
export class ChangePasswordDto {
    @IsString()
    @IsNotEmpty({ message: 'Current password is required.' })
    current_password: string;
  
    @IsString()
    @MinLength(8, { message: 'New password must be at least 8 characters long.' })
    @Matches(/(?=.*[A-Z])/, { message: 'New password must contain at least one uppercase letter.' })
    @Matches(/(?=.*[a-z])/, { message: 'New password must contain at least one lowercase letter.' })
    @Matches(/(?=.*\d)/, { message: 'New password must contain at least one number.' })
    @Matches(/(?=.*\W)/, { message: 'New password must contain at least one special character.' })
    @IsNotEmpty({ message: 'New password is required.' })
    new_password: string;
  
    @IsString()
    @IsNotEmpty({ message: 'Password confirmation is required.' })
    @Validate(PasswordMatch, ['new_password'], { message: 'Passwords do not match.' })
    confirm_password: string;
}
