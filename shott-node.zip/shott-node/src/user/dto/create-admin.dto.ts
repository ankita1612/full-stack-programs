import { Type } from "class-transformer";
import { IsArray, IsNotEmpty, IsNumber, IsOptional, IsString, Validate } from "class-validator";
import { Column } from "typeorm";

export class CreateAdminDto {
   
    @IsNumber()
    @IsOptional()
    @Type(() => Number) 
    id: number;

    @IsString()
    name: string;

    @IsString()
    @IsNotEmpty()
    email: string;

    @IsOptional()
    @IsString()
    profile_pic?: string;

    @IsString()
    @IsOptional()
    password: string;
    
    
    @IsArray()
    permissions: string[];

}