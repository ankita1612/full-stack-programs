import { IsNotEmpty, IsString, Matches } from 'class-validator';

export class UpdateUserBankDetailDto {
    @IsNotEmpty({ message: 'Bank name is required.' })
    @IsString()
    bank_name: string;

    @IsNotEmpty({ message: 'Account number is required.' })
    @Matches(/^\d{9,18}$/, {
        message: 'Invalid account number format',
    })
    @IsString()
    account_number: string;

    @IsNotEmpty({ message: 'Account holder name is required.' })
    @IsString()
    holder_name: string;

    @IsNotEmpty({ message: 'IFSC code is required.' })
    @Matches(/^[A-Z]{4}0[A-Z0-9]{6}$/, {
        message: 'Invalid IFSC code formate.',
    })
    @IsString()
    ifsc_code: string;
}
