import { IsString } from 'class-validator';

export class UpdateUserKycDetailDto {
    @IsString()
    pan_card: string;

    @IsString()
    adhar_card: string;

    @IsString()
    status: string;

    @IsString()
    reject_reason: string;
}
