import { IsOptional, IsString } from "class-validator";
import { Column } from "typeorm";

export class CreateUserDto {
   
    @IsString()
    name: string;

    @IsString()
    @IsOptional()
    email: string;
    
    @IsString()
    mobile: string;

    @IsString()
    @IsOptional()
    referral_code:string;

    @Column({ type: 'json' })
    permissions: [];

}