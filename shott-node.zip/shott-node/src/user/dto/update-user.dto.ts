import { IsBoolean, IsDate, IsString } from 'class-validator';

export class UpdateUserDto {
    @IsString()
    name: string;

    @IsString()
    otp: string;

    @IsString()
    profile_pic: string;

    @IsDate()
    otp_sent_time: Date;

    @IsBoolean()
    is_otp_verified: boolean;

    @IsString()
    avatar: string;

    @IsBoolean()
    is_completed_profile: boolean;

    @IsString()
    mobile: string;

    @IsString()
    referred_by: string;

    @IsString()
    referral_code: string;

    @IsString()
    fcm: string;

    @IsBoolean()
    is_online: boolean;
}
