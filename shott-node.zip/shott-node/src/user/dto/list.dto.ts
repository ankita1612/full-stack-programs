import { IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class ListDto {
    @IsNotEmpty({ message: 'Please provide valid page number.' })
    @IsString()
    page: string;

    @IsNotEmpty({ message: 'Please provide page data limit.' })
    @IsString()
    limit: string;

    @IsString()
    search: string;

    @IsOptional()
    @IsString()
    status: string;

    @IsOptional()
    @IsString()
    type: string;
}
