import { IsNotEmpty, IsNumber} from 'class-validator';

export class UpdateCoinDto {
    @IsNotEmpty({ message: 'Bank name is required.' })
    @IsNumber()
    coins: number;

}
