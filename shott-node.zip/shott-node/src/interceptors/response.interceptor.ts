import {
    CallHandler,
    ExecutionContext,
    HttpStatus,
    Injectable,
    NestInterceptor,
} from '@nestjs/common';
import { map, Observable } from 'rxjs';

@Injectable()
export class ResponseInterceptor implements NestInterceptor {
    private static getMessageCode(statusCode: number): string {
        // Return the name of the HttpStatus enum member
        return HttpStatus[statusCode] || 'UNKNOWN_ERROR';
    }

    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
        return next.handle().pipe(
            map((data) => {
                // Default to HttpStatus.OK if statusCode is not defined
                const statusCode = data?.statusCode || HttpStatus.OK;
                const messageCode =
                    ResponseInterceptor.getMessageCode(statusCode);

                // Check if `data` is not null or undefined and has a `message` property
                const hasMessage = data && typeof data.message === 'string';
                const response = {
                    error: false,
                    message: hasMessage ? data.message : '',
                    statusCode: statusCode,
                    messageCode: messageCode,
                    // data: data?.data || data || null,
                };
                if (data?.data) response['data'] = data?.data;
                if (!data?.data && !data?.statusCode) response['data'] = data;
                return response;
            }),
        );
    }
}
