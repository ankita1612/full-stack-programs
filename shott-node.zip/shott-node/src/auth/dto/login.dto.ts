import {
    IsArray,
    IsNotEmpty,
    IsOptional,
    IsString,
    Length,
} from 'class-validator';

export class LoginDto {
    @IsNotEmpty({ message: 'Please provide mobile number.' })
    @IsString()
    mobile: string;

    @IsOptional()
    @IsString()
    @Length(4, 4, { message: 'Otp must be exactly 4 characters long' })
    otp: string;

    @IsOptional()
    @IsString()
    role: string;

    @IsOptional()
    @IsArray()
    permissions: string[];
}
