import {
    IsEmail,
    IsNotEmpty,
    IsOptional,
    IsPhoneNumber,
    IsString,
    Length,
} from 'class-validator';

export class OtpDto {
    @IsNotEmpty({ message: 'Please provide mobile number.' })
    @IsString()
    mobile: string;

    @IsOptional()
    @Length(4, 4, { message: 'otp must be exactly 4 characters long' })
    @IsString()
    otp: string;

    @IsOptional()
    @IsString()
    fcm: string;
}
