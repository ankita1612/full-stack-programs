import { IsEmail, isEmail, IsNotEmpty, IsString } from 'class-validator';

export class AdminLoginDto {
    @IsNotEmpty({ message: 'Please provide valid email.' })
    @IsEmail()
    email: string;

    @IsNotEmpty({ message: 'Please provide valid password.' })
    @IsString()
    password: string;
}
