import { Body, Controller, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';
import { OtpDto } from './dto/otp.dto';
import { AdminLoginDto } from './dto/admin-login.dto';

@Controller('auth')
export class AuthController {
    constructor(private authService: AuthService) {}

    @Post('user/login')
    async login(@Body() loginDto: LoginDto) {
        return this.authService.login(loginDto);
    }

    @Post('admin/login')
    async adminLogin(@Body() loginDto: AdminLoginDto) {
        return this.authService.adminLogin(loginDto);
    }

    @Post('send-otp')
    async sendOtp(@Body() otpDto: OtpDto) {
        return this.authService.sendOtp(otpDto);
    }

    @Post('verify-otp')
    async verifyOtp(@Body() OtpDto: OtpDto) {
        return this.authService.verifyOtp(OtpDto);
    }
}
