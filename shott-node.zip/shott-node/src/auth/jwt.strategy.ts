import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { UserService } from 'src/user/user.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
    constructor(private userService: UserService) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: process.env.JWT_SECRET,
        });
    }

    async validate(payload: any) {
        if (payload?.is_user === true) {
            const user = await this.userService.findOneById(payload.sub);

            if (!user) {
                throw new UnauthorizedException('User not found');
            }

            if (Number(user?.status) === 0) {
                throw new UnauthorizedException(
                    'Your account is inactive.Please Contact to admin',
                );
            }

            return user; // Return the full user object with role
        } else if (payload.is_admin === true) {
            const user = await this.userService.findOneById(payload.sub);

            if (!user) {
                throw new UnauthorizedException('User not found');
            }

            return user; // Return the full user object with role
        } else {
            throw new UnauthorizedException('Invalid access token.');
        }
    }
}
