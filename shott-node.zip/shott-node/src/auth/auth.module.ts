import { Module } from '@nestjs/common';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from './jwt.strategy';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entity/user.entity';
import { UserService } from 'src/user/user.service';
import { Setting } from 'src/settings/entity/setting.entity';
import { UserBankDetail } from 'src/user/entity/user-bank-detail.entity';
import { UserKycDetail } from 'src/user/entity/user-kyc-detail.entity';
import { CsvExportService } from 'src/common/services/csv-export.service';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            User,
            Setting,
            UserBankDetail,
            UserKycDetail,
        ]),
        PassportModule,
        JwtModule.register({
            secret: process.env.JWT_SECRET,
            signOptions: { expiresIn: '9999 years' },
        }),
    ],
    providers: [AuthService, UserService, JwtStrategy,CsvExportService],
    controllers: [AuthController],
})
export class AuthModule {}
