import {
    HttpException,
    HttpStatus,
    Injectable,
    UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserService } from 'src/user/user.service';
import { LoginDto } from './dto/login.dto';
import { logger } from 'src/logger/winston.logger';
import { OtpDto } from './dto/otp.dto';
import { AdminLoginDto } from './dto/admin-login.dto';
import * as bcryptjs from 'bcryptjs';
import { Role } from 'src/common/enums/role.enum';

@Injectable()
export class AuthService {
    constructor(
        private userService: UserService,
        private jwtService: JwtService,
    ) {}

    async adminLogin(loginDto: AdminLoginDto) {
        try {
            let user = await this.userService.findByEmail(loginDto.email);

            if (!user) {
                throw new UnauthorizedException('Invalid email or password.');
            }

            const passwordMatches = await bcryptjs.compare(
                loginDto.password,
                user.password,
            );
            if (!passwordMatches) {
                throw new UnauthorizedException('Invalid email or password.');
            }

            const { password: _,otp,...result } = user;

            const payload = {
                email: user.email,
                sub: user.id,
                is_admin: true,
            };
            const secret = process.env.JWT_SECRET;
            const access_token = this.jwtService.sign(payload, { secret });

            return {
                message: 'Logged in successfully',
                statusCode: HttpStatus.OK,
                data: { ...result, access_token },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async login(loginDto: LoginDto) {
        try {
            let user = await this.userService.findByMobile(loginDto.mobile);

            if (!user) {
                user = await this.userService.create({
                    mobile: loginDto.mobile,
                    otp: await this.userService.generateOneTimePassword(4),
                    role: Role.User,
                    permissions: [],
                });

                await this.userService.update(
                    {
                        referral_code:
                            await this.userService.generateReferralCode(
                                user.id,
                            ),
                    },
                    user.id,
                );
            } else if (Number(user?.status) === 0) {
                throw new UnauthorizedException(
                    'Your account is inactive.Please Contact to admin',
                );
            } else {
                user = await this.userService.update(
                    {
                        otp: await this.userService.generateOneTimePassword(4),
                        otp_sent_time: new Date(),
                        is_otp_verified: false,
                    },
                    Number(user.id),
                );
            }

            return {
                statusCode: HttpStatus.CREATED,
                message: 'One Time Password sent successfully.',
                data: {
                    id: user.id,
                    otp: user.otp,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async sendOtp(otpDto: OtpDto) {
        try {
            const user = await this.userService.findByMobile(otpDto.mobile);

            if (!user) {
                throw new HttpException('User not found', HttpStatus.NOT_FOUND);
            }

            const payload = {
                otp: await this.userService.generateOneTimePassword(4),
                otp_sent_time: new Date(),
                is_otp_verified: false,
            };

            await this.userService.update(payload, Number(user.id));

            return {
                statusCode: HttpStatus.CREATED,
                message: 'One Time Password sent successfully.',
                data: {
                    id: user.id,
                    otp: payload.otp,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async verifyOtp(otpDto: OtpDto) {
        try {
            if (!otpDto.mobile || !otpDto.otp) {
                throw new HttpException(
                    'Please provide all credentials.',
                    HttpStatus.NOT_FOUND,
                );
            }

            const user = await this.userService.findByMobile(otpDto.mobile);

            if (!user) {
                throw new HttpException(
                    'User not found',
                    HttpStatus.BAD_REQUEST,
                );
            }

            // Get the difference in milliseconds

            const sendTime: Date = new Date(user.otp_sent_time);
            const currentTime: Date = new Date();
            const diffInMs: number = currentTime.getTime() - sendTime.getTime();

            // Convert milliseconds to minutes
            const diffInMinutes = diffInMs / 1000 / 60;

            if (user.otp !== otpDto.otp || diffInMinutes > 10) {
                throw new HttpException(
                    'Invalid One Time Password.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            await this.userService.update(
                {
                    otp: '',
                    is_otp_verified: true,
                    fcm: otpDto?.fcm ? otpDto.fcm : '',
                },
                Number(user.id),
            );

            let response = await this.userService.findByMobile(otpDto.mobile);

            //============ Update the user with the new token
            const payload = {
                mobile: response.mobile,
                sub: response.id,
                is_user: true,
                user_info: {
                    id: response.id,
                    name: response.name,
                    is_online: response.is_online,
                    profile_pic: response.profile_pic,
                    wallet: response.wallet,
                    unutilized_wallet: response.unutilized_wallet,
                    winning_wallet: response.winning_wallet,
                    bonus_wallet: response.bonus_wallet,
                },
            };
            const secret = process.env.JWT_SECRET;
            response.access_token = this.jwtService.sign(payload, { secret });

            const { password: _,otp,...result } = response;
            return {
                message: 'Logged in successfully',
                statusCode: HttpStatus.OK,
                data: result,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}
