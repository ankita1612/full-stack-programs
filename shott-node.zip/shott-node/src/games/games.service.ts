import { HttpException, HttpStatus, Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Games } from './entity/game.entity';
import { ILike, Repository } from 'typeorm';
import { logger } from 'src/logger/winston.logger';
import { GameModule } from 'src/common/enums/game.enum';
import { ListDto } from 'src/user/dto/list.dto';

@Injectable()
export class GamesService implements OnModuleInit{

    constructor(
        @InjectRepository(Games)
        private readonly gameRepository: Repository<Games>,
    ){}

    async onModuleInit() {
        const gamesCount = await this.gameRepository.count();
         if(gamesCount === 0){
            // Seed data
            const gamesToInsert = [
                { name: GameModule.callbreak },
                { name: GameModule.rummy },
                { name: GameModule.teenpatti },
                { name: GameModule.ludo },
            ];
            await this.gameRepository.save(gamesToInsert);
        }
    }

      /**fetch games **/
      async fetchGames(reqQuery:ListDto) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;
            //const games = await this.gameRepository.find();

            const whereCondition: any[] = [];

            if (reqQuery.search) {
                const searchValue = ILike(`%${reqQuery.search}%`);
                whereCondition.push(
                    { name:  searchValue },
                    { status: searchValue },
                );
            }

            const [result, count] = await this.gameRepository.findAndCount({
                where: whereCondition.length > 0 ? whereCondition : undefined, 
                select: {
                    id: true,
                    name: true,
                    status: true,
                    created_at: true,
                },
                order: {
                    created_at: 'ASC',
                },
                take: limit,
                skip: offset,
            });
            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                message: 'All games list.',
                statusCode: HttpStatus.OK,
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    /**update game status **/
    async updateStatus(id:number) {
        try {
            const games = await this.gameRepository.findOne({ 
                where: {
                    id: id,
                  }, 
            });
            if(!games){
                 throw new HttpException(
                    'Please pass valid game id',
                    HttpStatus.BAD_REQUEST
                )
            }
            const status = games.status ? false : true;

            await this.gameRepository.update(id, { status: status });
            return {
                message: 'All games list.',
                statusCode: HttpStatus.OK,
                data: games || [],
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}
