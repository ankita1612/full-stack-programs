import { Controller, Get, Param, ParseIntPipe, Patch, Query, UseGuards } from '@nestjs/common';
import { GamesService } from './games.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { Role } from 'src/common/enums/role.enum';
import { Roles,Permissions } from 'src/roles-permissions.decorator';
import { PermissionModule } from 'src/common/enums/user.permission';
import { ListDto } from 'src/user/dto/list.dto';

@Controller('games')
@UseGuards(JwtAuthGuard)
export class GamesController {

    constructor(
        private readonly gameService: GamesService
    ) {}

    @Get('/list')
    async gameList(@Query() reqQuery:ListDto) {
        const record = await this.gameService.fetchGames(reqQuery);
        return record;
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.Games)
    @Patch('/:id')
    async gameUpdate(@Param('id',ParseIntPipe) id: number) {
        const record = await this.gameService.updateStatus(id);
        return record;
    }
}
