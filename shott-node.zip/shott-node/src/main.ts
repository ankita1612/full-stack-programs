import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { json, urlencoded } from 'body-parser';
import { ConfigService } from '@nestjs/config';
import { ResponseInterceptor } from './interceptors/response.interceptor';
import { CustomExceptionFilter } from './exceptions.filter';
import { logger } from './logger/winston.logger';

async function bootstrap() {
    const app = await NestFactory.create(AppModule);
    app.useGlobalPipes(
        new ValidationPipe({
            whitelist: true,
        }),
    );

    const configService = app.get(ConfigService);
    app.use(json());
    app.use(urlencoded({ extended: true }));
    app.useGlobalInterceptors(new ResponseInterceptor());
    app.useGlobalFilters(new CustomExceptionFilter());

    app.enableCors({
        origin: '*',
    });

    const port = configService.get<number>('PORT');
    await app.listen(port);
    logger.info(`Application is running on: http://localhost:${port}`);
}
bootstrap();
