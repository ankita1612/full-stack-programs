import { HttpStatus, Injectable, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Setting } from './entity/setting.entity';
import { Repository } from 'typeorm';
import { logger } from 'src/logger/winston.logger';
import { UpdateSettingDto } from './dto/update-setting.dto';
import { CMSDto } from './dto/cms.dto';
import { CMS } from './entity/cms.entity';

@Injectable()
export class SettingsService implements OnModuleInit{
    constructor(
        @InjectRepository(Setting)
        private readonly settingRepository: Repository<Setting>,

        @InjectRepository(CMS)
        private readonly cmsRepository: Repository<CMS>,
    ) {}


    async onModuleInit() {
        // Clear existing data (optional)
        const settingCount = await this.settingRepository.count();

        if(settingCount === 0){
            // Seed data
            await this.settingRepository.save({
                min_redeem: 0,
                joing_bonus: 0,
                referral_bonus: 0,
                referral_prefix: 'SHOTT_',
                logo: 'logo_url', 
                server_firebase_key: 'firebase_key', 
                min_withdrawal: 0,
                share_text: 'Please refer this app & Earn', 
                currency: 'INR', 
                app_version: '1.0.0', 
                is_force_update: false,
                one_coin_conversion_rate:2 
            });
        }

    }
    async fetchRecord(baseUrl: string): Promise<{ message: string; statusCode: number; data: {} }> {
        try {
            const records = await this.settingRepository.find();
    
            if (records.length > 0) {
                records.forEach(record => {
                    if (record.logo) {
                        record.logo = `${baseUrl}/${record.logo}`;
                    }
                });
            }
    
            return {
                message: 'All Setting data.',
                statusCode: HttpStatus.OK,
                data: records[0] || null, // return the first record or null
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    

    /**update Settings**/
    async update (id:number ,updateSettingDto:UpdateSettingDto): Promise<{ message: string; statusCode: number; data: {} }> {

        try {
            const update = await this.settingRepository.update(id, updateSettingDto);

            return {
                message: 'Setting is updated.',
                statusCode: HttpStatus.OK,
                data: update || null,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
        
    }


    /**create CMS**/
    async createCMS (cmsDto:CMSDto): Promise<{ message: string; statusCode: number; data: {} }> {

        try {
            const create = await this.cmsRepository.create(cmsDto);

            return {
                message: 'Cms fields is added.',
                statusCode: HttpStatus.OK,
                data: create || null,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
        
    }
        /**update CMS**/
        async updateCMS (id:number ,cmsDto:CMSDto): Promise<{ message: string; statusCode: number; data: {} }> {

            try {
                const update = await this.cmsRepository.update(id,cmsDto);
    
                return {
                    message: 'Cms fields is updated.',
                    statusCode: HttpStatus.OK,
                    data: update || null,
                };
            } catch (error) {
                logger.error(error);
                throw error;
            }
            
        }
        /**fetch CMS data**/
        async fetchCMS():Promise<{ message: string; statusCode: number; data: {} }>{
            try{
             const records = await this.cmsRepository.find();
    
             return {
                 message: 'All cms data.',
                 statusCode: HttpStatus.OK,
                 data: records[0] || null,
             };
            }catch (error) {
                logger.error(error);
                throw error;
            }
          
        }

}
