import { Body, Controller, Get, Param, Patch, Post, Req, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { SettingsService } from './settings.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Permissions, Roles } from 'src/roles-permissions.decorator';
import { PermissionModule } from "../common/enums/user.permission";
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { UpdateSettingDto } from './dto/update-setting.dto';
import { CMSDto } from './dto/cms.dto';
import { Role } from 'src/common/enums/role.enum';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { Request } from 'express';

@Controller('settings')
@UseGuards(JwtAuthGuard)
@UseGuards(RoleAndPermissionGuard)
@Roles(Role.Admin, Role.SubAdmin)
@Permissions(PermissionModule.Setting)

export class SettingsController {
    constructor(private readonly settingsService: SettingsService) {}

   
    @Get()
    async fetch(@Req() request: Request) {
        // Dynamically construct the base URL
        const baseUrl = `${request.protocol}://${request.get('host')}`;
        const record = await this.settingsService.fetchRecord(baseUrl);
        return record;
    }

    @Patch('/update/:id')
    @UseInterceptors(
        FileInterceptor('logo', {
            storage: diskStorage({
                destination: 'public',
                filename: (req, file, cb) => {
                    const uniqueSuffix =
                        Date.now() + '-' + Math.round(Math.random() * 1e9);
                    const nameTab = file.originalname.split('.');
                    // const subArray = nameTab.slice(0, -1);
                    const ext = `.${nameTab[nameTab.length - 1]}`;
                    const originalName = 'logo';
                    const filename = `${originalName}-${uniqueSuffix}${ext}`;
                    cb(null, filename);
                },
            }),
        }),
    )
    async update(        
        @Param('id') id:number,
        @Body() updateSettingDto:UpdateSettingDto,
        @UploadedFile() file: Express.Multer.File,
    ) {
        if(file){
            updateSettingDto.logo =file.path;
        }
        return this.settingsService.update(id, updateSettingDto)
        
    }

    @Post('/cms/create')
    async createCMS(
        @Body() cmsDto:CMSDto) {
        return this.settingsService.createCMS(cmsDto)
        
    }

    @Get('/cms')
    async cmsFetch() {
        const record = await this.settingsService.fetchCMS();
        return record;
    }

    @Patch('/update/cms/:id')
    async updateCMS(
        @Param('id') id:number,
        @Body() cmsDto:CMSDto) {
            console.log(cmsDto);
            
        return this.settingsService.updateCMS(id, cmsDto)
        
    }
}
