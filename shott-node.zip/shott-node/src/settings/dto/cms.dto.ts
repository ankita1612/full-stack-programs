import { IsString} from "class-validator";

export class CMSDto{

    @IsString()
    contact_us:string;

    @IsString()
    about_us:string;

    @IsString()
    refund_policy:string;

    @IsString()
    terms:string;

    @IsString()
    privacy_policy:string;

    @IsString()
    help_support:string;
}