import { Type } from 'class-transformer';
import { IsNotEmpty, IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';

export class UpdateSettingDto {
    @IsNumber()
    @IsNotEmpty()
    @Type(() => Number) 
    min_redeem: number;

    @IsNumber()
    @IsNotEmpty()
    @Type(() => Number) 
    joining_bonus: number;

    @IsNumber()
    @IsNotEmpty()
    @Type(() => Number) 
    referral_bonus: number;

    @IsString()
    @IsNotEmpty()
    referral_prefix: string;

    @IsString()
    @IsNotEmpty()
    app_version: string;

    @IsString()
    @IsOptional()
    logo: string;

    @IsString()
    @IsOptional()
    server_firebase_key: string;

    @IsNumber()
    @IsNotEmpty()
    @Type(() => Number) 
    min_withdrawal: number;

    @IsString()
    @IsNotEmpty()
    share_text: string;

    @IsString()
    @IsNotEmpty()
    currency: string;

    @IsBoolean()
    @IsNotEmpty()
    @Type(() => Boolean) 
    is_force_update: boolean;

    @IsNumber()
    @IsNotEmpty()
    @Type(() => Number) 
    one_coin_conversion_rate:number;
}
