import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('cms')
export class CMS {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: 'text' })
    contact_us: string;

    @Column({ type: 'text' })
    about_us: string;

    @Column({ type: 'text' })
    refund_policy: string;

    @Column({ type: 'text' })
    terms: string;

    @Column({ type: 'text' })
    privacy_policy: string;

    @Column({ type: 'text' })
    help_support: string;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
