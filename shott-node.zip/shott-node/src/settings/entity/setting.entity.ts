import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('setting')
export class Setting {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: 'int', width: 11, default: 0 })
    min_redeem: number;

    @Column({ type: 'int', width: 11, default: 0 })
    joining_bonus: number;

    @Column({ type: 'int', width: 11, default: 0 })
    referral_bonus: number;

    @Column()
    referral_prefix: string;

    @Column()
    app_version: string;

    @Column()
    logo: string;

    @Column()
    server_firebase_key: string;

    @Column({ type: 'int', width: 11 })
    min_withdrawal: number;

    @Column()
    share_text: string;

    @Column()
    currency: string;

    @Column()
    is_force_update: boolean;

    @Column({ type: 'int', width: 11 })
    one_coin_conversion_rate: number;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
