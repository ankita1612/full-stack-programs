import { IsBoolean, IsNotEmpty, IsNumber } from "class-validator";

export class CreateCallbreakDto {

    @IsNotEmpty({ message: 'Please provide valid boot value.' })
    @IsNumber()
    boot_value: number;

    @IsNotEmpty({ message: 'Please provide valid status value.' })
    @IsBoolean()
    status: boolean;
}
