import { PartialType } from '@nestjs/mapped-types';
import { CreateCallbreakDto } from './create-callbreak.dto';
import { IsBoolean, IsNumber, IsOptional } from 'class-validator';

export class UpdateCallbreakDto extends PartialType(CreateCallbreakDto) {

    @IsOptional()
    @IsNumber()
    boot_value: number;

    @IsOptional()
    @IsBoolean()
    status: boolean;
}
