import { User } from 'src/user/entity/user.entity';
import {
    MasterCard,
    Suits,
} from 'src/master-cards/entities/master-card.entity';
import { RedisService } from 'src/common/redis/redis.service';
import { InjectRepository } from '@nestjs/typeorm';
import { CallbreakGateway } from './callbreak.gateway';
import { CallbreakPlayers } from './entities/callbreak-players.entity';
import { CallbreakRoomRounds } from './entities/callbreak-room-rounds.entity';
import { CallbreakWebSocketEvents } from './websocket-events.enum';
import { CallbreakCardDistributions } from './entities/callbreak-card-distributions.entity';
import {
    CallbreakRooms,
    GameStage,
    RoomStatus,
} from './entities/callbreak-rooms.entity';
import { ILike, In, LessThan, Not, Repository } from 'typeorm';
import {
    Body,
    forwardRef,
    HttpException,
    HttpStatus,
    Inject,
    Injectable,
} from '@nestjs/common';
import { CallbreakScore } from './entities/callbreak-score.entity';
import { CallbreakTurns } from './entities/callbreak-turns.entity';
import { CallbreakTable } from './entities/callbreak-table.entity';
import { UserService } from 'src/user/user.service';
import { logger } from 'src/logger/winston.logger';
import { CreateCallbreakDto } from './dto/create-callbreak.dto';
import { ListDto } from 'src/user/dto/list.dto';

@Injectable()
export class CallbreaksService {
    constructor(
        @InjectRepository(CallbreakRooms)
        private readonly callbreakRoomRepo: Repository<CallbreakRooms>,
        @InjectRepository(CallbreakScore)
        private readonly callbreakScoreRepo: Repository<CallbreakScore>,
        @InjectRepository(CallbreakTable)
        private readonly callbreakTableRepo: Repository<CallbreakTable>,
        @InjectRepository(CallbreakPlayers)
        private readonly callbreakPlayersRepo: Repository<CallbreakPlayers>,
        @InjectRepository(CallbreakTurns)
        private readonly callbreakTurnsRepo: Repository<CallbreakTurns>,
        @InjectRepository(MasterCard)
        private readonly masterCardRepo: Repository<MasterCard>,
        @InjectRepository(CallbreakRoomRounds)
        private readonly callbreakRoomRoundsRepo: Repository<CallbreakRoomRounds>,
        @InjectRepository(CallbreakCardDistributions)
        private readonly callbreakCardDistributionsRepo: Repository<CallbreakCardDistributions>,
        private readonly redisService: RedisService,
        @Inject(forwardRef(() => CallbreakGateway))
        private readonly callbreakGateway: CallbreakGateway,

        private readonly userService: UserService,
    ) {}

    /* JOIN ROOM */
    async addPlayerToRoom(joinRoomDto: {
        user_id: number;
        socketId: string;
        callbreak_table_id: number;
        user_info: Partial<User>;
    }): Promise<void> {
        try {
            const { user_id, socketId, callbreak_table_id, user_info } =
                joinRoomDto;

            const checkValidTable = await this.callbreakTableRepo.findOne({
                where: {
                    id: callbreak_table_id,
                },
            });

            if (!checkValidTable) {
                return this.callbreakGateway.notifyRoomAssignment(socketId, {
                    error: true,
                    statusCode: HttpStatus.BAD_REQUEST,
                    message: 'Invalid callbreak table.',
                    data: '',
                });
            }

            const userExistInOtherRoom =
                await this.checkUserExistInOtherRoom(user_id);

            if (userExistInOtherRoom) {
                return this.callbreakGateway.notifyRoomAssignment(socketId, {
                    error: false,
                    statusCode: HttpStatus.OK,
                    message: 'User already has current session.',
                    data: userExistInOtherRoom.callbreak_room,
                });
            }

            const getAvailableSpot = async (
                callbreak_room_id: number,
            ): Promise<number> => {
                const playersOfRoom = await this.callbreakPlayersRepo.find({
                    where: { callbreak_room_id },
                });
                const existingPositions = playersOfRoom.map(
                    (player) => player.player_position,
                );
                return [1, 2, 3, 4].find(
                    (pos) => !existingPositions.includes(pos),
                )!;
            };

            const assignPlayerToRoom = async (
                room: CallbreakRooms,
                isMasterPlayer = false,
                playerPosition = 1,
            ) => {
                const new_user_info = {
                    ...user_info,
                    callbreak_room_id: room.id,
                };
                await this.callbreakPlayersRepo.save({
                    callbreak_room_id: room.id,
                    callbreak_table_id: room.callbreak_table_id,
                    user_id,
                    user_info: new_user_info,
                    is_active: true,
                    is_master_player: isMasterPlayer,
                    is_dealer: isMasterPlayer,
                    is_your_turn: isMasterPlayer,
                    player_position: playerPosition,
                });

                await this.userService.updateCallBreakRoomId([user_id], {
                    callbreak_room_id: room.id,
                });

                await this.redisService.addUserToRoom(
                    'callbreak',
                    `callbreak_${room.id}`,
                    user_id,
                );

                const assignedRoomDetails =
                    await this.callbreakRoomRepo.findOne({
                        where: {
                            id: room.id,
                        },
                        relations: ['players'],
                    });

                return this.callbreakGateway.notifyRoomAssignment(socketId, {
                    error: false,
                    statusCode: HttpStatus.OK,
                    message: 'Room assigned.',
                    data: assignedRoomDetails,
                });
            };

            const availableRoom =
                await this.getAvailableRoom(callbreak_table_id);
            if (availableRoom) {
                availableRoom.users_count += 1;
                if (availableRoom.users_count === 4) {
                    availableRoom.status = RoomStatus.PREPARING;
                    availableRoom.users_count === 4 &&
                        setTimeout(() => {
                            this.generateRoomRound(availableRoom.id);
                        }, 500);
                }
                await this.callbreakRoomRepo.save(availableRoom);
                const playerPosition = await getAvailableSpot(availableRoom.id);
                return assignPlayerToRoom(availableRoom, false, playerPosition);
            }

            const newRoom = await this.callbreakRoomRepo.save({
                callbreak_table_id,
                users_count: 1,
                status: RoomStatus.OPEN,
            });

            return assignPlayerToRoom(newRoom, true);
        } catch (error) {
            console.log('Error while adding player to room:', error);
            return this.callbreakGateway.notifyRoomAssignment(
                joinRoomDto.socketId,
                {
                    error: true,
                    statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                    message: 'Internal server error',
                },
            );
        }
    }

    /* LEAVE ROOM */

    async leavePlayerFromRoom(userId: number, roomId: number) {
        try {
            const checkRoom = await this.callbreakRoomRepo.findOne({
                where: {
                    id: roomId,
                },
            });

            if (!checkRoom) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'Invalid callbreak room',
                    data: '',
                };
            }

            const player = await this.callbreakPlayersRepo.findOne({
                where: {
                    user_id: userId,
                    is_quit: false,
                    callbreak_room: {
                        id: roomId,
                        status: Not(RoomStatus.FINISHED),
                    },
                },
                relations: ['callbreak_room'],
            });

            if (!player) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'User not found in the provided room.',
                    data: '',
                };
            }

            const { callbreak_room } = player;
            const updateMasterPlayer = async () => {
                try {
                    const new_master_user =
                        await this.callbreakPlayersRepo.findOne({
                            where: {
                                callbreak_room_id: player.callbreak_room_id,
                                is_quit: false,
                                is_active: true,
                                is_offline: false,
                            },
                        });
                    if (new_master_user) {
                        this.callbreakPlayersRepo.update(new_master_user.id, {
                            is_master_player: true,
                            is_dealer: true,
                        });
                    }
                } catch (error) {
                    console.log(
                        'getting error while update master user [ callbreak ]: ',
                        error,
                    );
                }
            };

            switch (callbreak_room.status) {
                case RoomStatus.OPEN:
                    if (callbreak_room.users_count === 1) {
                        this.callbreakRoomRepo.delete(callbreak_room.id);
                        this.redisService.deleteRoom(
                            'callbreak',
                            callbreak_room.toString(),
                        );
                    } else {
                        this.callbreakPlayersRepo.delete(player.id);
                        await this.callbreakRoomRepo.update(callbreak_room.id, {
                            users_count: --callbreak_room.users_count,
                        });
                    }
                    if (player.is_master_player) updateMasterPlayer();
                    this.redisService.removeUserToRoom(
                        'callbreak',
                        `callbreak_${callbreak_room.id}`,
                        userId,
                    );
                    break;

                case RoomStatus.PLAYING:
                case RoomStatus.PREPARING:
                    await this.callbreakPlayersRepo.update(player.id, {
                        is_master_player: false,
                        is_quit: true,
                        is_dealer: false,
                        is_active: false,
                        is_your_turn: false,
                        is_offline: true,
                    });
                    if (player.is_master_player) updateMasterPlayer();
                    break;

                default:
                    return {
                        error: true,
                        statusCode: HttpStatus.BAD_REQUEST,
                        message: 'Invalid room status',
                    };
            }

            const updatedRoomDetails = await this.callbreakRoomRepo.findOne({
                where: {
                    id: roomId,
                },
                relations: ['players'],
            });

            return {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'User left successfully.',
                data: updatedRoomDetails ? updatedRoomDetails : {},
            };
        } catch (error) {
            console.log('Error while leaving player from room:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    /* START GAME */

    async startGame(
        userId: number,
        roomId: number,
        random_trump_card: boolean = false,
    ) {
        try {
            const checkRoom = await this.callbreakRoomRepo.findOne({
                where: {
                    id: roomId,
                },
            });

            if (!checkRoom) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'Invalid callbreak room',
                    data: '',
                };
            }

            const player = await this.callbreakPlayersRepo.findOne({
                where: {
                    user_id: userId,
                    callbreak_room: {
                        id: roomId,
                        status: Not(RoomStatus.FINISHED),
                    },
                },
                relations: ['callbreak_room'],
            });

            if (!player) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'User not found in the provided room.',
                    data: '',
                };
            } else if (!player.is_master_player) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'Only master player can start the game.',
                    data: '',
                };
            } else if (player.callbreak_room.users_count !== 4) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'No enough players to start game.',
                    data: '',
                };
            } else if (player.callbreak_room.status === RoomStatus.PLAYING) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'Game is already started.',
                    data: '',
                };
            }

            await this.callbreakRoomRepo.update(roomId, {
                status: RoomStatus.PLAYING,
                stage: GameStage.GAME_START,
            });

            const getCurrentRound = await this.callbreakRoomRoundsRepo.findOne({
                where: {
                    callbreak_rooms_id: roomId,
                    is_current_round: true,
                },
            });

            const room = await this.callbreakRoomRepo.findOne({
                where: {
                    id: roomId,
                },
                relations: ['players'],
            });

            if (random_trump_card) {
                const trumpSuit = [
                    Suits.CLUBS,
                    Suits.DIAMONDS,
                    Suits.HEARTS,
                    Suits.SPADES,
                ];

                await this.callbreakRoomRoundsRepo.update(getCurrentRound.id, {
                    trump_card:
                        trumpSuit[Math.floor(Math.random() * trumpSuit.length)],
                });
            }

            return {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'Game started successfully.',
                data: room
                    ? {
                          ...room,
                          round_number: getCurrentRound?.round_number,
                          round_id: getCurrentRound?.id,
                      }
                    : {},
            };
        } catch (error) {
            console.log('Error while start game [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    /* SET BET */

    async setBet(
        userId: number,
        roomId: number,
        roundId: number,
        betValue: number,
    ) {
        try {
            const errorResponse = (statusCode: number, message: string) => ({
                error: true,
                statusCode,
                message,
                data: {},
            });

            const setBetValidation = async () => {
                /* CHECK ROOM */

                const [room, round, checkAlreadySetBet, player] =
                    await Promise.all([
                        this.callbreakRoomRepo.findOne({
                            where: {
                                id: roomId,
                            },
                        }),
                        this.callbreakRoomRoundsRepo.findOne({
                            where: {
                                id: roundId,
                            },
                        }),
                        this.callbreakScoreRepo.findOne({
                            where: {
                                user_id: userId,
                                callbreak_round_id: roundId,
                                callbreak_room_id: roomId,
                            },
                        }),
                        this.callbreakPlayersRepo.findOne({
                            where: {
                                user_id: userId,
                                callbreak_room: {
                                    id: roomId,
                                    status: Not(RoomStatus.FINISHED),
                                },
                            },
                            relations: ['callbreak_room'],
                        }),
                    ]);

                if (!room)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Invalid callbreak room.',
                    );

                if (!round)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Round not found for this room.',
                    );

                if (!round.is_current_round)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Provided round is not current round, you can not set bet for this round.',
                    );

                if (betValue > 13 && betValue <= 0)
                    return errorResponse(
                        HttpStatus.BAD_REQUEST,
                        'Bet values should be between 1 to 13.',
                    );

                if (checkAlreadySetBet)
                    return errorResponse(
                        HttpStatus.BAD_REQUEST,
                        'You had already set bet for this round.',
                    );

                if (!player)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'User not found in the provided room.',
                    );

                if (player.callbreak_room.status !== RoomStatus.PLAYING)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Game is not started yet.',
                    );

                return {
                    error: false,
                    data: {
                        room,
                        round,
                        player,
                    },
                };
            };

            const payload = await setBetValidation();
            if (payload.error) return payload;

            let roomData: CallbreakRooms;
            let roundData: CallbreakRoomRounds;

            if ('room' in payload?.data)
                roomData = payload?.data?.room as CallbreakRooms;
            if ('round' in payload?.data)
                roundData = payload?.data?.round as CallbreakRoomRounds;

            /* UPDATE GAME STAGE */
            if (
                roundData.round_number === 1 &&
                roomData.stage == GameStage.GAME_START
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.FIRST_ROUND_SET_BET_SCREEN,
                });
            } else if (
                roundData.round_number === 2 &&
                roomData.stage == GameStage.FIRST_ROUND_RESULT_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.SECOND_ROUND_SET_BET_SCREEN,
                });
            } else if (
                roundData.round_number === 3 &&
                roomData.stage == GameStage.SECOND_ROUND_RESULT_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.THIRD_ROUND_SET_BET_SCREEN,
                });
            }

            await this.callbreakScoreRepo.save({
                user_id: userId,
                callbreak_room_id: roomId,
                callbreak_round_id: roundId,
                bet_value: betValue,
                total_points: -betValue,
                points: -betValue,
            });

            const response = await this.callbreakScoreRepo.find({
                where: {
                    callbreak_room_id: roomId,
                    callbreak_round_id: roundId,
                },
            });

            return {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'Bet set successfully.',
                data: response,
            };
        } catch (error) {
            console.log('Error while set bet [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    async autoSetBet(userId: number, roomId: number, roundId: number) {
        try {
            const errorResponse = (statusCode: number, message: string) => ({
                error: true,
                statusCode,
                message,
                data: {},
            });

            /* CHECK ROOM */

            const [roomData, roundData, masterPlayerData] = await Promise.all([
                this.callbreakRoomRepo.findOne({
                    where: {
                        id: roomId,
                    },
                    relations: ['players'],
                }),
                this.callbreakRoomRoundsRepo.findOne({
                    where: {
                        id: roundId,
                        callbreak_rooms_id: roomId,
                    },
                }),
                this.callbreakPlayersRepo.findOne({
                    where: {
                        user_id: userId,
                        callbreak_room: {
                            id: roomId,
                            status: Not(RoomStatus.FINISHED),
                        },
                    },
                    relations: ['callbreak_room'],
                }),
            ]);

            if (!roomData)
                return errorResponse(
                    HttpStatus.NOT_FOUND,
                    'Invalid callbreak room.',
                );

            if (!roundData)
                return errorResponse(
                    HttpStatus.NOT_FOUND,
                    'Round not found for this room.',
                );

            if (!roundData.is_current_round)
                return errorResponse(
                    HttpStatus.NOT_FOUND,
                    'Provided round is not current round, you can not auto set bet for this round.',
                );

            if (
                [
                    RoomStatus.OPEN.toString(),
                    RoomStatus.PREPARING.toString(),
                ].includes(roomData.status)
            )
                return errorResponse(
                    HttpStatus.BAD_REQUEST,
                    'Game is not started yet.',
                );

            if (roomData.status == RoomStatus.FINISHED)
                return errorResponse(
                    HttpStatus.BAD_REQUEST,
                    'Game is already finished.',
                );

            if (!masterPlayerData)
                return errorResponse(
                    HttpStatus.NOT_FOUND,
                    'User not found in the provided room.',
                );

            if (!masterPlayerData.is_master_player)
                return errorResponse(
                    HttpStatus.BAD_REQUEST,
                    'Only master player can auto set bet.',
                );

            if (masterPlayerData.callbreak_room.users_count !== 4)
                return errorResponse(
                    HttpStatus.BAD_REQUEST,
                    'No enough players to auto set bet',
                );

            /* UPDATE GAME STAGE */
            if (
                roundData.round_number === 1 &&
                roomData.stage == GameStage.GAME_START
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.FIRST_ROUND_SET_BET_SCREEN,
                });
            } else if (
                roundData.round_number === 2 &&
                roomData.stage == GameStage.FIRST_ROUND_RESULT_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.SECOND_ROUND_SET_BET_SCREEN,
                });
            } else if (
                roundData.round_number === 3 &&
                roomData.stage == GameStage.SECOND_ROUND_RESULT_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.THIRD_ROUND_SET_BET_SCREEN,
                });
            }

            for (const player of roomData.players) {
                const userId = player.user_id;
                const alreadySetBet = await this.callbreakScoreRepo.findOne({
                    where: {
                        user_id: userId,
                        callbreak_round_id: roundId,
                        callbreak_room_id: roomId,
                    },
                });

                if (!alreadySetBet) {
                    const betValue = Math.floor(Math.random() * 13) + 1;

                    await this.callbreakScoreRepo.save({
                        user_id: userId,
                        callbreak_room_id: roomId,
                        callbreak_round_id: roundId,
                        bet_value: betValue,
                        total_points: -betValue,
                        points: -betValue,
                    });
                }
            }

            const response = await this.callbreakScoreRepo.find({
                where: {
                    callbreak_room_id: roomId,
                    callbreak_round_id: roundId,
                },
            });

            return {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'Bet set successfully.',
                data: response,
            };
        } catch (error) {
            console.log('Error while auto set bet [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    /* SELECT CARD */

    async selectCard(
        userId: number,
        roomId: number,
        roundId: number,
        masterCardId: number,
    ) {
        try {
            // Utility to handle errors and return early
            const errorResponse = (statusCode: number, message: string) => ({
                error: true,
                statusCode,
                message,
                data: {},
            });

            // Validate room, round, and card ownership in a single function
            const selectCardValidation = async () => {
                const [
                    room,
                    round,
                    droppedCard,
                    checkMastercardDropped,
                    player,
                    checkCardOwner,
                ] = await Promise.all([
                    this.callbreakRoomRepo.findOne({ where: { id: roomId } }),
                    this.callbreakRoomRoundsRepo.findOne({
                        where: { id: roundId },
                    }),
                    this.masterCardRepo.findOne({
                        where: { id: masterCardId },
                    }),
                    this.callbreakCardDistributionsRepo.findOne({
                        where: {
                            user_id: userId,
                            callbreak_rooms_id: roomId,
                            callbreak_round_id: roundId,
                            master_card_id: masterCardId,
                            is_drop_card: true,
                        },
                    }),
                    this.callbreakPlayersRepo.findOne({
                        where: {
                            user_id: userId,
                            callbreak_room: {
                                id: roomId,
                                status: Not(RoomStatus.FINISHED),
                            },
                        },
                        relations: ['callbreak_room'],
                    }),
                    this.callbreakCardDistributionsRepo.findOne({
                        where: {
                            user_id: userId,
                            master_card_id: masterCardId,
                            callbreak_rooms_id: roomId,
                            callbreak_round_id: roundId,
                        },
                    }),
                ]);

                if (!room)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Invalid callbreak room.',
                    );
                if (!round)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Round not found for this room.',
                    );
                if (!droppedCard)
                    return errorResponse(HttpStatus.NOT_FOUND, 'Invalid card.');
                if (checkMastercardDropped)
                    return errorResponse(
                        HttpStatus.BAD_REQUEST,
                        'Card is already dropped.',
                    );
                if (!player)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'User not found in the provided room.',
                    );
                if (player.callbreak_room.status !== RoomStatus.PLAYING)
                    return errorResponse(
                        HttpStatus.BAD_REQUEST,
                        'Game is not started yet.',
                    );
                if (!checkCardOwner)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Card owner not found.',
                    );

                return {
                    error: false,
                    data: { room, round, droppedCard, player },
                };
            };

            const payload = await selectCardValidation();
            if (payload.error) return payload;

            let roundData: CallbreakRoomRounds;
            let droppedCardData: MasterCard;
            let playerData: CallbreakPlayers;
            let roomData: CallbreakRooms;

            if ('player' in payload?.data)
                playerData = payload?.data?.player as CallbreakPlayers;
            if ('round' in payload?.data)
                roundData = payload?.data?.round as CallbreakRoomRounds;
            if ('droppedCard' in payload?.data)
                droppedCardData = payload?.data?.droppedCard as MasterCard;
            if ('room' in payload?.data)
                roomData = payload?.data?.room as CallbreakRooms;

            // update game stage

            if (
                roundData.round_number === 1 &&
                roomData.stage === GameStage.FIRST_ROUND_SET_BET_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.FIRST_ROUND_PLAYING,
                });
            } else if (
                roundData.round_number === 2 &&
                roomData.stage === GameStage.SECOND_ROUND_SET_BET_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.SECOND_ROUND_PLAYING,
                });
            } else if (
                roundData.round_number === 3 &&
                roomData.stage === GameStage.THIRD_ROUND_SET_BET_SCREEN
            ) {
                this.callbreakRoomRepo.update(roomId, {
                    stage: GameStage.THIRD_ROUND_PLAYING,
                });
            }

            // Fetch active players and turn details
            const [activePlayers, activePlayersCount, latestTurn] =
                await Promise.all([
                    this.callbreakPlayersRepo.find({
                        where: { callbreak_room_id: roomId, is_quit: false },
                        order: { player_position: 'ASC' },
                    }),
                    this.callbreakPlayersRepo.count({
                        where: { callbreak_room_id: roomId, is_quit: false },
                    }),
                    this.callbreakTurnsRepo.findOne({
                        where: {
                            callbreak_room_id: roomId,
                            callbreak_round_id: roundId,
                        },
                        order: { id: 'DESC' },
                    }),
                ]);

            const currentTurnNumber = latestTurn
                ? (await this.callbreakTurnsRepo.count({
                      where: {
                          callbreak_room_id: roomId,
                          callbreak_round_id: roundId,
                          turn_number: latestTurn.turn_number,
                      },
                  })) < activePlayersCount
                    ? latestTurn.turn_number
                    : latestTurn.turn_number + 1
                : 1;

            const [firstCardOfTurn, playerRestCardsOfDeck] = await Promise.all([
                this.callbreakTurnsRepo.findOne({
                    where: {
                        turn_number: currentTurnNumber,
                        callbreak_room_id: roomId,
                        callbreak_round_id: roundId,
                    },
                    relations: ['master_card'],
                    order: { created_at: 'ASC' },
                }),
                this.callbreakCardDistributionsRepo.find({
                    where: {
                        callbreak_rooms_id: roomId,
                        callbreak_round_id: roundId,
                        user_id: userId,
                        is_drop_card: false,
                    },
                    relations: ['master_card'],
                }),
            ]);

            if (firstCardOfTurn) {
                const isValidCard = await this.checkForValidDroppedCards(
                    firstCardOfTurn.master_card,
                    droppedCardData,
                    playerRestCardsOfDeck,
                );
                if (!isValidCard)
                    return errorResponse(
                        HttpStatus.NOT_FOUND,
                        'Invalid card for this turn.',
                    );
            }

            // Update card drop status
            const dropCardResult =
                await this.callbreakCardDistributionsRepo.update(
                    {
                        callbreak_rooms_id: roomId,
                        callbreak_round_id: roundId,
                        master_card_id: masterCardId,
                        user_id: userId,
                    },
                    { is_drop_card: true },
                );
            if (dropCardResult.affected === 0)
                return errorResponse(
                    HttpStatus.BAD_REQUEST,
                    'Card dropped status is not updated.',
                );

            // Get the next player
            const nextPlayer =
                activePlayers[
                    (activePlayers.findIndex(
                        (player) => player.user_id === userId,
                    ) +
                        1) %
                        activePlayers.length
                ];

            // Save the current player's turn and update player turn status
            await Promise.all([
                this.callbreakTurnsRepo.save({
                    user_id: userId,
                    card_id: masterCardId,
                    turn_number: currentTurnNumber,
                    callbreak_room_id: roomId,
                    callbreak_round_id: roundId,
                }),
                this.callbreakPlayersRepo.update(playerData.id, {
                    is_your_turn: false,
                }),
                this.callbreakPlayersRepo.update(nextPlayer.id, {
                    is_your_turn: true,
                }),
                this.callbreakRoomRoundsRepo.update(roundId, {
                    last_card_drop_time: new Date(),
                    next_card_drop_time: new Date(
                        new Date().getTime() + 15 * 1000,
                    ),
                }),
            ]);

            // Check if it's the last card of the turn and determine the winner
            // const checkIsLastCardOfTurn = await this.callbreakTurnsRepo.count({
            //     where: {
            //         callbreak_room_id: roomId,
            //         callbreak_round_id : roundId,
            //         turn_number: currentTurnNumber,
            //     },
            // });

            // const isLastCardOfRound = await this.callbreakTurnsRepo.count({
            //     where: {
            //         callbreak_room_id: roomId,
            //         callbreak_round_id : roundId
            //     },
            // });

            const [checkIsLastCardOfTurn, checkIsLastCardOfRound] =
                await Promise.all([
                    this.callbreakTurnsRepo.count({
                        where: {
                            callbreak_room_id: roomId,
                            callbreak_round_id: roundId,
                            turn_number: currentTurnNumber,
                        },
                    }),
                    this.callbreakTurnsRepo.count({
                        where: {
                            callbreak_room_id: roomId,
                            callbreak_round_id: roundId,
                        },
                    }),
                ]);

            if (checkIsLastCardOfTurn === activePlayersCount) {
                const winnerUserId = await this.getWinnerUser(
                    roomId,
                    roundId,
                    currentTurnNumber,
                    roundData.trump_card,
                );
                await Promise.all([
                    this.callbreakTurnsRepo.update(
                        {
                            turn_number: currentTurnNumber,
                            callbreak_room_id: roomId,
                            callbreak_round_id: roundId,
                            user_id: winnerUserId,
                        },
                        { is_winner: true },
                    ),
                    this.updateUserScore(winnerUserId, roomId, roundId),
                ]);
            }

            //this.userService.updateCallBreakRoomId([user_id], { callbreak_room_id: room.id });

            // NOTIFY ROOM PLAYERS ROUND IS COMPLETED
            if (checkIsLastCardOfRound === 52) {
                this.roundCompleted(roomId, roundData.round_number);

                /* UPDATE GAME STAGE */
                if (
                    roundData.round_number === 1 &&
                    roomData.stage === GameStage.FIRST_ROUND_PLAYING
                ) {
                    this.callbreakRoomRepo.update(roomId, {
                        stage: GameStage.FIRST_ROUND_RESULT_SCREEN,
                    });
                } else if (
                    roundData.round_number === 2 &&
                    roomData.stage === GameStage.SECOND_ROUND_PLAYING
                ) {
                    this.callbreakRoomRepo.update(roomId, {
                        stage: GameStage.SECOND_ROUND_RESULT_SCREEN,
                    });
                } else if (
                    roundData.round_number === 3 &&
                    roomData.stage === GameStage.THIRD_ROUND_PLAYING
                ) {
                    this.callbreakRoomRepo.update(roomId, {
                        stage: GameStage.FINAL_RESULT_SCREEN,
                    });
                }
            }

            return {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'Card processed successfully',
                data: {
                    currentPlayers: playerData,
                    nextPlayer: nextPlayer,
                    recentlyDroppedCard: droppedCardData,
                },
            };
        } catch (error) {
            console.log('Error while selecting card [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    /* COMPUTER CHAL */

    async computerChal(userId: number, roomId: number, roundId: number) {
        try {
            const [activePlayersCount, latestTurn] = await Promise.all([
                this.callbreakPlayersRepo.count({
                    where: { callbreak_room_id: roomId, is_quit: false },
                }),
                this.callbreakTurnsRepo.findOne({
                    where: {
                        callbreak_room_id: roomId,
                        callbreak_round_id: roundId,
                    },
                    order: { id: 'DESC' },
                }),
            ]);

            const currentTurnNumber = latestTurn
                ? (await this.callbreakTurnsRepo.count({
                      where: {
                          callbreak_room_id: roomId,
                          callbreak_round_id: roundId,
                          turn_number: latestTurn.turn_number,
                      },
                  })) < activePlayersCount
                    ? latestTurn.turn_number
                    : latestTurn.turn_number + 1
                : 1;

            const [firstCardOfTurn, playerRestCardsOfDeck] = await Promise.all([
                this.callbreakTurnsRepo.findOne({
                    where: {
                        turn_number: currentTurnNumber,
                        callbreak_room_id: roomId,
                        callbreak_round_id: roundId,
                    },
                    relations: ['master_card'],
                    order: { created_at: 'ASC' },
                }),
                this.callbreakCardDistributionsRepo.find({
                    where: {
                        callbreak_rooms_id: roomId,
                        callbreak_round_id: roundId,
                        user_id: userId,
                        is_drop_card: false,
                    },
                    relations: ['master_card'],
                }),
            ]);

            if (firstCardOfTurn && playerRestCardsOfDeck.length) {
                const validGameCardList = playerRestCardsOfDeck.filter(
                    (card) =>
                        card.master_card.suit ===
                            firstCardOfTurn.master_card.suit &&
                        card.master_card.weightage >
                            firstCardOfTurn.master_card.weightage,
                );

                // If no higher weightage cards, filter cards that match the suit
                if (validGameCardList.length === 0) {
                    validGameCardList.push(
                        ...playerRestCardsOfDeck.filter(
                            (card) =>
                                card.master_card.suit ===
                                firstCardOfTurn.master_card.suit,
                        ),
                    );
                }

                if (validGameCardList.length === 0) {
                    validGameCardList.push(...playerRestCardsOfDeck);
                }

                const decided_dropCard = validGameCardList[0]?.master_card.id;

                return await this.selectCard(
                    userId,
                    roomId,
                    roundId,
                    decided_dropCard,
                );
            } else if (playerRestCardsOfDeck.length === 0) {
                return {
                    error: true,
                    statusCode: HttpStatus.NOT_FOUND,
                    message: 'User do not have un-drop cards',
                    data: {},
                };
            } else {
                const decided_dropCard =
                    playerRestCardsOfDeck[0].master_card.id;

                return await this.selectCard(
                    userId,
                    roomId,
                    roundId,
                    decided_dropCard,
                );
            }
        } catch (error) {
            console.log('Error while computer chal [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    /* ROUND COMPLETED */

    async roundCompleted(roomId: number, roundNumber: number) {
        try {
            const data = await this.callbreakRoomRepo.findOne({
                where: { id: roomId },
                relations: [
                    'callbreak_score',
                    'callbreak_score.callbreak_round',
                    'players',
                ],
            });

            if (!data) {
                return this.callbreakGateway.notifyRoomPlayers(
                    CallbreakWebSocketEvents.ROUND_COMPLETED,
                    roomId,
                    {
                        error: true,
                        statusCode: HttpStatus.NOT_FOUND,
                        message: 'Room not found for calculate round score.',
                        data: {},
                    },
                );
            }

            const getWinnerUser = (overAllScore) => {
                let winner = overAllScore[0];

                for (const player of overAllScore) {
                    if (player.overAllScore > winner.overAllScore) {
                        winner = player;
                    }
                }

                return winner;
            };

            const playerLookup = this.createPlayerLookup(data.players);
            const { result, overallScores } = this.calculateRoundScores(
                data.callbreak_score,
                playerLookup,
            );

            this.callbreakGateway.notifyRoomPlayers(
                CallbreakWebSocketEvents.ROUND_COMPLETED,
                roomId,
                {
                    error: false,
                    statusCode: HttpStatus.OK,
                    message: 'Round score is calculated successfully.',
                    data: { result, overallScores },
                },
            );

            if (roundNumber === 3) {
                const winnerUser = getWinnerUser(overallScores);
                await this.callbreakRoomRepo.update(roomId, {
                    status: RoomStatus.FINISHED,
                    winner_user_id: winnerUser.user_id,
                });

                this.callbreakGateway.notifyRoomPlayers(
                    CallbreakWebSocketEvents.FINISH_GAME,
                    roomId,
                    {
                        error: false,
                        statusCode: HttpStatus.OK,
                        message: 'Game finish',
                        data: { result, overallScores, winnerUser },
                    },
                );
                const players = await this.getPlayerByRoomId(roomId);
                // Extract the user IDs from the players
                const userIds = players.map((player) => player.user_id);
                /***update room id for all players***/
                this.userService.updateCallBreakRoomId(userIds, {
                    callbreak_room_id: 0,
                });
            } else {
                setTimeout(() => {
                    this.generateRoomRound(roomId);
                }, 1000);
            }

            return;
        } catch (error) {
            console.error('Error while completing round [ callbreak ]:', error);
            return {
                error: true,
                statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
                message: 'Internal server error',
            };
        }
    }

    private createPlayerLookup(players: any[]): Record<number, string> {
        return players.reduce((lookup, player) => {
            lookup[player.user_id] = player.user_info.name;
            return lookup;
        }, {});
    }

    private calculateRoundScores(
        scores: any[],
        playerLookup: Record<number, string>,
    ) {
        const result = {};
        const overallScores = {};

        scores.forEach((score) => {
            const roundKey = `round_${score.callbreak_round.round_number}`;
            const playerName = playerLookup[score.user_id];

            // Initialize the round if it doesn't exist
            if (!result[roundKey]) {
                result[roundKey] = [];
            }

            // Add player score to the round result
            result[roundKey].push({
                user_id: score.user_id,
                name: playerName,
                total_points: score.total_points,
            });

            // Update overall score
            if (!overallScores[score.user_id]) {
                overallScores[score.user_id] = {
                    user_id: score.user_id,
                    name: playerName,
                    overAllScore: 0,
                };
            }
            // overallScores[score.user_id].overAllScore += score.total_points;
            overallScores[score.user_id].overAllScore = parseFloat(
                (
                    overallScores[score.user_id].overAllScore +
                    score.total_points
                ).toFixed(2),
            );
        });

        // Convert overallScores object to an array
        const overAllScoreArray = Object.values(overallScores);

        return { result, overallScores: overAllScoreArray };
    }

    /* HELPERS */

    async getAvailableRoom(
        callbreak_table_id: number,
    ): Promise<CallbreakRooms> {
        try {
            return await this.callbreakRoomRepo.findOne({
                where: {
                    status: RoomStatus.OPEN,
                    users_count: LessThan(4),
                    callbreak_table_id: callbreak_table_id,
                },
            });
        } catch (error) {
            console.log(
                'Getting error while get available room [ helper ]',
                error,
            );
            return error;
        }
    }

    async checkUserExistInOtherRoom(userId: number): Promise<CallbreakPlayers> {
        try {
            return await this.callbreakPlayersRepo.findOne({
                where: {
                    user_id: userId,
                    is_quit: false,
                    callbreak_room: {
                        status: In([
                            RoomStatus.OPEN,
                            RoomStatus.PLAYING,
                            RoomStatus.PREPARING,
                        ]),
                    },
                },
                relations: ['callbreak_room', 'callbreak_room.players'],
            });
        } catch (error) {
            console.log(
                'Getting error while check user exist in other room [ helper ]',
                error,
            );
            return error;
        }
    }

    async generateRoomRound(roomId: number): Promise<void> {
        const checkExistRound = await this.callbreakRoomRoundsRepo.findOne({
            where: {
                callbreak_rooms_id: roomId,
            },
            order: {
                created_at: 'DESC',
            },
        });

        if (checkExistRound && checkExistRound.round_number === 3) {
            this.callbreakGateway.notifyRoomPlayers(
                CallbreakWebSocketEvents.CARD_DISTRIBUTED,
                roomId,
                {
                    error: true,
                    statusCode: HttpStatus.BAD_REQUEST,
                    message: 'Game is already finished.',
                    data: [],
                },
            );
            return;
        }

        let roundId: number;

        if (!checkExistRound) {
            const round = await this.callbreakRoomRoundsRepo.save({
                round_number: 1,
                is_current_round: true,
                callbreak_rooms_id: roomId,
            });

            roundId = round.id;
        } else {
            const [update, round] = await Promise.all([
                this.callbreakRoomRoundsRepo.update(checkExistRound.id, {
                    is_current_round: false,
                }),

                this.callbreakRoomRoundsRepo.save({
                    round_number: (checkExistRound.round_number += 1),
                    is_current_round: true,
                    callbreak_rooms_id: roomId,
                    trump_card: checkExistRound.trump_card,
                }),
            ]);

            roundId = round.id;
        }

        this.cardDistribution(roomId, roundId);
    }

    async cardDistribution(roomId: number, roundId: number): Promise<void> {
        const masterCards = await this.masterCardRepo.find({});

        const roomPlayers = await this.redisService.getRoomPlayers(
            'callbreak',
            `callbreak_${roomId}`,
        );

        if (roomPlayers.length !== 4) {
            this.callbreakGateway.notifyRoomPlayers(
                CallbreakWebSocketEvents.CARD_DISTRIBUTED,
                roomId,
                {
                    error: true,
                    statusCode: HttpStatus.BAD_REQUEST,
                    message:
                        'Card distribution failed, room has no enough players.',
                    data: [],
                },
            );
            return;
        }

        function shuffleDeck(deck) {
            for (let i = deck.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [deck[i], deck[j]] = [deck[j], deck[i]]; // Swap cards
            }
            return deck;
        }

        // Function to distribute cards among users
        function distributeCards(cards: MasterCard[], users) {
            const userCards = {};
            users.forEach((userId: number) => (userCards[userId] = []));

            cards.forEach((card: MasterCard, index: number) => {
                const userId = users[index % users.length];
                userCards[userId].push({
                    master_card_id: card.id,
                    master_card: {
                        rank: card.rank,
                        suit: card.suit,
                        weightage: card.weightage,
                    },
                    callbreak_rooms_id: roomId,
                    callbreak_round_id: roundId,
                    user_id: userId,
                });
            });

            return userCards;
        }

        const shuffledDeck = shuffleDeck(masterCards);

        // Distribute cards to users
        const distributedCards = distributeCards(shuffledDeck, roomPlayers);

        let userDistributedCard = Object.values(distributedCards).flat();

        /*
        *-----------------------------------------------------------------------
        * IF QUITE USER DON'T WANT TO DISTRIBUTE CARD THEN UNCOMMENT BELOW CODE
        *-----------------------------------------------------------------------
        * 
        const roomUsers = await this.callbreakPlayersRepo.find({
            where: {
                callbreak_room_id: roomId,
                is_quit: false,
            },

            select: {
                user_id: true,
            },
        });

        const eligiblePlayers = roomUsers.map((item) => item.user_id);

        userDistributedCard = userDistributedCard.filter((item: any) =>
            eligiblePlayers.includes(item.user_id),
        );
        
        *
        * END
        */

        const data = await this.callbreakCardDistributionsRepo.save(
            userDistributedCard.map((item: any) => {
                return {
                    master_card_id: item.master_card_id,
                    callbreak_rooms_id: item.callbreak_rooms_id,
                    callbreak_round_id: item.callbreak_round_id,
                    user_id: item.user_id,
                };
            }),
        );

        return this.callbreakGateway.notifyRoomPlayers(
            CallbreakWebSocketEvents.CARD_DISTRIBUTED,
            roomId,
            {
                error: false,
                statusCode: HttpStatus.OK,
                message: 'Card distributed successfully.',
                data: userDistributedCard,
            },
        );
    }

    async getWinnerUser(
        roomId: number,
        roundId: number,
        turnNumber: number,
        trumpCard: string,
    ): Promise<number | undefined> {
        // Fetch current turn cards, ordered by creation time
        const currentTurnCards = await this.callbreakTurnsRepo.find({
            where: {
                turn_number: turnNumber,
                callbreak_round_id: roundId,
                callbreak_room_id: roomId,
            },
            relations: ['master_card'],
            order: {
                created_at: 'DESC',
            },
        });

        const masterCards = currentTurnCards.map((item) => item.master_card);
        if (masterCards.length === 0) return undefined;

        const leadingSuit = masterCards[0].suit;

        const { suiteCards, trumpCards } = masterCards.reduce(
            (acc, card) => {
                if (card.suit === leadingSuit) acc.suiteCards.push(card);
                if (card.suit === trumpCard) acc.trumpCards.push(card);
                return acc;
            },
            { suiteCards: [] as MasterCard[], trumpCards: [] as MasterCard[] },
        );

        let winningCard: MasterCard | null = null;

        if (trumpCards.length > 0) {
            winningCard = trumpCards.reduce((prev, current) =>
                current.weightage > prev.weightage ? current : prev,
            );
        } else if (suiteCards.length > 0) {
            winningCard = suiteCards.reduce((prev, current) =>
                current.weightage > prev.weightage ? current : prev,
            );
        }

        if (!winningCard) return undefined;

        const winnerTurn = currentTurnCards.find(
            (item) => item.card_id === winningCard!.id,
        );

        return winnerTurn?.user_id; // Return the winner's user ID
    }

    async updateUserScore(
        winnerUserId: number,
        roomId: number,
        roundId: number,
    ) {
        const userScore = await this.callbreakScoreRepo.findOne({
            where: {
                user_id: winnerUserId,
                callbreak_room_id: roomId,
                callbreak_round_id: roundId,
            },
        });

        if (!userScore) return;

        let { bonus_value, points, total_points, in_hand_value, bet_value } =
            userScore;

        in_hand_value += 1;

        if (in_hand_value > bet_value) {
            bonus_value += 0.1;
            total_points += 0.1;
        } else if (in_hand_value === bet_value) {
            points = total_points = bet_value;
        }

        await this.callbreakScoreRepo.update(userScore.id, {
            bonus_value,
            points,
            total_points,
            in_hand_value,
        });
    }

    async checkForValidDroppedCards(
        firstCardOfTurn: MasterCard,
        playerDroppedCard: MasterCard,
        playerRestCardOfDeck: CallbreakCardDistributions[],
    ): Promise<boolean> {
        // Filter cards that match the first card's suit and have a higher weightage
        const validGameCardList = playerRestCardOfDeck.filter(
            (card) =>
                card.master_card.suit === firstCardOfTurn.suit &&
                card.master_card.weightage > firstCardOfTurn.weightage,
        );

        // If no higher weightage cards, filter cards that match the suit
        if (validGameCardList.length === 0) {
            validGameCardList.push(
                ...playerRestCardOfDeck.filter(
                    (card) => card.master_card.suit === firstCardOfTurn.suit,
                ),
            );
        }

        // If no matching suit cards, all cards are valid
        if (validGameCardList.length === 0) return true;

        // Check if the dropped card is in the valid card list
        return validGameCardList.some(
            (deckCard) => playerDroppedCard.id === deckCard.master_card.id,
        );
    }
    /**find all */
    async findAll() {
        const table = await this.callbreakTableRepo.find({
            where: {
                status: true,
            },
        });
        return {
            statusCode: HttpStatus.OK,
            message: 'Call break table list.',
            data: table,
        };
    }
    /**join table */
    async joinTable(user: any, @Body() body: any) {
        if (!body.callbreak_table_id) {
            throw new HttpException('Invalid table id', HttpStatus.BAD_REQUEST);
        }
        const checkValidTable = await this.callbreakTableRepo.findOne({
            where: {
                id: body.callbreak_table_id,
                status: true,
            },
        });

        if (!checkValidTable) {
            throw new HttpException('Invalid table id', HttpStatus.BAD_REQUEST);
        }
        if (user.coins >= checkValidTable.boot_value) {
            const data = await this.updateUserCoins(
                user.id,
                checkValidTable.boot_value,
            );
            return {
                statusCode: HttpStatus.OK,
                message: 'Table join successfully.',
                data: data,
            };
        } else {
            throw new HttpException(
                'You do not have enough coins to join this table. Please purchase coins first.',
                HttpStatus.BAD_REQUEST,
            );
        }
    }

    /**update user coins **/
    async updateUserCoins(user_id: number, coins: number) {
        try {
            const user = await this.userService.updateCoins(
                user_id,
                coins,
                true,
            );
            return user;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**add table **/
    async addTable(createCallbreakDto: CreateCallbreakDto) {
        try {
            const table = await this.findOne({
                boot_value: createCallbreakDto.boot_value,
            });
            if (table) {
                throw new HttpException(
                    'Table already exist with this value.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            // Await the result of the asynchronous operation
            const tabledata =
                await this.callbreakTableRepo.save(createCallbreakDto);

            return {
                message: 'Callbreak table has been created.',
                statusCode: HttpStatus.CREATED,
                data: tabledata,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findOne(payload: any): Promise<CallbreakTable> {
        try {
            return await this.callbreakTableRepo.findOne({ where: payload });
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**update table **/
    async updateTable(id: number, createCallbreakDto: CreateCallbreakDto) {
        try {
            const tableE = await this.findOne({
                id: id,
            });
            if (!tableE) {
                throw new HttpException(
                    'Table not exist with this value.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            const table = await this.findOne({
                boot_value: createCallbreakDto.boot_value,
                id: Not(id),
            });
            if (table) {
                throw new HttpException(
                    'Table already exist with this value.',
                    HttpStatus.BAD_REQUEST,
                );
            }

            // Await the result of the asynchronous operation
            const tabledata = await this.callbreakTableRepo.update(
                id,
                createCallbreakDto,
            );

            return {
                message: 'Callbreak table has been updated.',
                statusCode: HttpStatus.OK,
                data: tabledata,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
    /**get admin */
    async get(reqQuery: ListDto): Promise<any> {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            // Initialize where condition
            const whereCondition: any[] = [];

            // Only add conditions if search is not empty
            if (reqQuery.search) {
                const searchValue = ILike(`%${reqQuery.search}%`);
                whereCondition.push(
                    { boot_value: searchValue },
                    { status: searchValue },
                );
            }
            // Fetch the data using findAndCount for pagination
            const [result, count] = await this.callbreakTableRepo.findAndCount({
                where: whereCondition.length > 0 ? whereCondition : undefined,
                select: {
                    id: true,
                    boot_value: true,
                    status: true,
                    created_at: true,
                },
                order: {
                    created_at: 'ASC',
                },
                take: limit,
                skip: offset,
            });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'All Tables.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async getPlayerByRoomId(roomId: number) {
        try {
            // Query players from the callbreakPlayersRepo based on room ID
            return await this.callbreakPlayersRepo.find({
                where: { callbreak_room_id: roomId },
            });
        } catch (error) {
            logger.error(`Failed to get players for room ${roomId}: `, error);
            throw error;
        }
    }
}
