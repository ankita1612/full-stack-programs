import { User } from 'src/user/entity/user.entity';
import { Module } from '@nestjs/common';
import { Setting } from 'src/settings/entity/setting.entity';
import { BullModule } from '@nestjs/bull';
import { JwtService } from '@nestjs/jwt';
import { RedisModule } from 'src/common/redis/redis.module';
import { UserService } from 'src/user/user.service';
import { QueueService } from 'src/common/queue/queue.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserKycDetail } from 'src/user/entity/user-kyc-detail.entity';
import { CallbreakRooms } from './entities/callbreak-rooms.entity';
import { CallbreakTable } from './entities/callbreak-table.entity';
import { CallbreakTurns } from './entities/callbreak-turns.entity';
import { UserBankDetail } from 'src/user/entity/user-bank-detail.entity';
import { CallbreaksService } from './callbreaks.service';
import { CallbreakGateway } from './callbreak.gateway';
import { CallbreakRoomRounds } from './entities/callbreak-room-rounds.entity';
import { CallbreaksController } from './callbreaks.controller';
import { CallbreakTransactions } from './entities/callbreak-transaction.entity';
import { CallbreakQueueProcessor } from './callbreak-queue.processor';
import { CallbreakCardDistributions } from './entities/callbreak-card-distributions.entity';
import { CallbreakPlayers } from './entities/callbreak-players.entity';
import { MasterCard } from 'src/master-cards/entities/master-card.entity';
import { CallbreakScore } from './entities/callbreak-score.entity';

@Module({
    imports: [
        TypeOrmModule.forFeature([
            CallbreakCardDistributions,
            CallbreakRooms,
            CallbreakRoomRounds,
            CallbreakTable,
            CallbreakTurns,
            CallbreakTransactions,
            User,
            UserBankDetail,
            UserKycDetail,
            Setting,
            CallbreakPlayers,
            MasterCard,
            CallbreakScore,
            CallbreakTurns,
        ]),
        BullModule.registerQueue({ name: 'callbreakQueue' }),
        RedisModule,
    ],
    controllers: [CallbreaksController],
    providers: [
        CallbreaksService,
        CallbreakGateway,
        CallbreakQueueProcessor,
        QueueService,
        JwtService,
        UserService,
    ],
    exports: [CallbreaksService],
})
export class CallbreaksModule {}
