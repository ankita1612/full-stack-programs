import { Test, TestingModule } from '@nestjs/testing';
import { CallbreaksController } from './callbreaks.controller';
import { CallbreaksService } from './callbreaks.service';

describe('CallbreaksController', () => {
    let controller: CallbreaksController;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [CallbreaksController],
            providers: [CallbreaksService],
        }).compile();

        controller = module.get<CallbreaksController>(CallbreaksController);
    });

    it('should be defined', () => {
        expect(controller).toBeDefined();
    });
});
