export enum CallbreakWebSocketEvents {
    JOIN_ROOM = 'join-room',
    START_GAME = 'start-game',
    SET_BET = 'set-bet',
    AUTO_SET_BET = 'auto-set-bet',
    CARD_DISTRIBUTED = 'card-distributed',
    SELECT_CARD = 'select-card',
    ROUND_COMPLETED = 'round-completed',
    FINISH_GAME = 'finish-game',
    LEAVE_ROOM = 'leave-room',
    COMPUTER_CHAL = 'computer-chal',
    AUTH_ERROR = 'auth-error',
}
