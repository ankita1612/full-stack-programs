import {
    WebSocketGateway,
    SubscribeMessage,
    WebSocketServer,
    OnGatewayConnection,
    OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Role } from 'src/common/enums/role.enum';
import { User } from 'src/user/entity/user.entity';
import { JwtService } from '@nestjs/jwt';
import { UserService } from 'src/user/user.service';
import { QueueService } from 'src/common/queue/queue.service';
import { RedisService } from 'src/common/redis/redis.service';
import { Server, Socket } from 'socket.io';
import { CallbreaksService } from './callbreaks.service';
import { forwardRef, HttpStatus, Inject } from '@nestjs/common';
import { CallbreakWebSocketEvents } from './websocket-events.enum';

@WebSocketGateway({ namespace: 'callbreak', cors: true })
export class CallbreakGateway
    implements OnGatewayConnection, OnGatewayDisconnect
{
    @WebSocketServer()
    server: Server;

    constructor(
        @Inject(forwardRef(() => CallbreaksService))
        private readonly callbreaksService: CallbreaksService,
        private readonly queueService: QueueService,
        private readonly jwtService: JwtService,
        private readonly userService: UserService,
        private readonly redisService: RedisService,
    ) {}

    /*
     *  CONNECTION
     */

    afterInit(server: Server) {
        console.log('WebSocket server initialized');
    }

    async handleConnection(client: Socket) {
        try {
            const token = client.handshake.headers.token;

            // Check if token exists
            if (!token) {
                return this.handleUnauthorizeRequest(client);
            }

            // Validate the token using the JWT service
            const decodeToken = await this.jwtService.verify(token.toString(), {
                secret: process.env.JWT_SECRET,
            });

            if (!decodeToken) {
                return this.handleUnauthorizeRequest(client);
            }
            const user = await this.verifyUserAccess(Number(decodeToken.sub));
            if (!user) {
                return this.handleUnauthorizeRequest(client);
            }

            client.join(user.id.toString()); // roomId will be user unique id

            // set user online
            this.userService.update({ is_online: true }, user.id);

            // Attach user data to the socket instance
            client.data.user = user;
            console.log(`Client connected: ${client.id}`);
        } catch (error) {
            console.log('Getting error while handle connection', error);

            return this.handleUnauthorizeRequest(client);
        }
    }

    async handleDisconnect(client: Socket) {
        try {
            const userId = Number(client?.data?.user?.id);

            userId && client.leave(userId.toString()); // roomId will be user unique id

            // set user offline
            userId && this.userService.update({ is_online: false }, userId);
            console.log('Client disconnected:', client.id);
        } catch (error) {
            console.log('Getting error while handle  disconnect', error);
            return;
        }
    }

    /*
     *  EVENTS
     */

    @SubscribeMessage('test')
    async testEvent(client: Socket): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);
            this.server
                .to(userId.toString())
                .emit('test', { message: 'working' });
        } catch (error) {
            console.log('Getting error while emit test event', error);
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.JOIN_ROOM)
    async handleJoinCallbreakRoom(
        client: Socket,
        payload: { callbreak_table_id: number },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            this.queueService.addToQueue(
                'callbreakQueue',
                'assignCallbreakRoom',
                {
                    callbreak_table_id: payload.callbreak_table_id,
                    user_id: userId,
                    socketId: client.id,
                    user_info: client.data.user,
                },
            );
        } catch (error) {
            console.log(
                'Getting error while handle  listen [ join-room ]',
                error,
            );
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.LEAVE_ROOM)
    async handleLeaveCallbreakRoom(
        client: Socket,
        payload: {
            room_id: number;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const leave = await this.callbreaksService.leavePlayerFromRoom(
                userId,
                payload.room_id,
            );

            if (leave.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of [...roomUSers, userId]) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.LEAVE_ROOM,
                            JSON.stringify(leave),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.LEAVE_ROOM,
                        JSON.stringify(leave),
                    );
            }
        } catch (error) {
            console.log('Getting error while callbreak [ leave-room ]', error);
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.START_GAME)
    async startGame(
        client: Socket,
        payload: {
            room_id: number;
            random_trump_card: boolean;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const startGame = await this.callbreaksService.startGame(
                userId,
                payload.room_id,
                payload.random_trump_card,
            );

            if (startGame.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of roomUSers) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.START_GAME,
                            JSON.stringify(startGame),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.START_GAME,
                        JSON.stringify(startGame),
                    );
            }
        } catch (error) {
            console.log('Getting error while callbreak [ start-game ]', error);
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.SET_BET)
    async setBet(
        client: Socket,
        payload: {
            room_id: number;
            round_id: number;
            bet_value: number;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const setBet = await this.callbreaksService.setBet(
                userId,
                payload.room_id,
                payload.round_id,
                payload.bet_value,
            );

            if (setBet.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of roomUSers) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.SET_BET,
                            JSON.stringify(setBet),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.SET_BET,
                        JSON.stringify(setBet),
                    );
            }
        } catch (error) {
            console.log('Getting error while  callbreak [ set-bet ] :', error);
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.SELECT_CARD)
    async selectCard(
        client: Socket,
        payload: {
            room_id: number;
            round_id: number;
            master_card_id: number;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const selectCard = await this.callbreaksService.selectCard(
                userId,
                payload?.room_id,
                payload?.round_id,
                payload?.master_card_id,
            );

            if (selectCard.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of roomUSers) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.SELECT_CARD,
                            JSON.stringify(selectCard),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.SELECT_CARD,
                        JSON.stringify(selectCard),
                    );
            }
        } catch (error) {
            console.log(
                'Getting error while  callbreak [ select-card ] :',
                error,
            );
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.COMPUTER_CHAL)
    async computerChal(
        client: Socket,
        payload: {
            room_id: number;
            round_id: number;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const computerChal = await this.callbreaksService.computerChal(
                userId,
                payload?.room_id,
                payload?.round_id,
            );

            if (computerChal.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of roomUSers) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.SELECT_CARD,
                            JSON.stringify(computerChal),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.COMPUTER_CHAL,
                        JSON.stringify(computerChal),
                    );
            }
        } catch (error) {
            console.log(
                'Getting error while  callbreak [ computer chal ] :',
                error,
            );
            return;
        }
    }

    @SubscribeMessage(CallbreakWebSocketEvents.AUTO_SET_BET)
    async autoSetBet(
        client: Socket,
        payload: {
            room_id: number;
            round_id: number;
        },
    ): Promise<void> {
        try {
            const userId = Number(client?.data?.user?.id);

            const autoSetBet = await this.callbreaksService.autoSetBet(
                userId,
                payload?.room_id,
                payload?.round_id,
            );

            if (autoSetBet.error === false) {
                const roomId = `callbreak_${payload.room_id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const user_id of roomUSers) {
                    this.server
                        .to(user_id.toString())
                        .emit(
                            CallbreakWebSocketEvents.SET_BET,
                            JSON.stringify(autoSetBet),
                        );
                }
            } else {
                this.server
                    .to(userId.toString())
                    .emit(
                        CallbreakWebSocketEvents.AUTO_SET_BET,
                        JSON.stringify(autoSetBet),
                    );
            }
        } catch (error) {
            console.log(
                'Getting error while  callbreak [ auto set-bet ] :',
                error,
            );
            return;
        }
    }
    /*
     *  HELPERS
     */

    async notifyRoomAssignment(clientId: string, data: any) {
        try {
            if (data.error == false) {
                const roomId = `callbreak_${data.data.id}`;

                const roomUSers = await this.redisService.getRoomPlayers(
                    'callbreak',
                    roomId,
                );

                for (const userId of roomUSers) {
                    this.server
                        .to(userId.toString())
                        .emit(
                            CallbreakWebSocketEvents.JOIN_ROOM,
                            JSON.stringify(data),
                        );
                }
            } else {
                this.server
                    .to(clientId)
                    .emit(
                        CallbreakWebSocketEvents.JOIN_ROOM,
                        JSON.stringify(data),
                    );
            }
        } catch (error) {
            console.error('Getting error while emit [ join-room ]:', error);
            return;
        }
    }

    async notifyRoomPlayers(event_name: string, room_id: number, data: any) {
        try {
            const roomId = `callbreak_${room_id}`;

            const roomUSers = await this.redisService.getRoomPlayers(
                'callbreak',
                roomId,
            );

            for (const userId of roomUSers) {
                this.server
                    .to(userId.toString())
                    .emit(event_name, JSON.stringify(data));
            }
        } catch (error) {
            console.error(`Getting error while emit [ ${event_name} ]:`, error);
            return;
        }
    }

    private handleUnauthorizeRequest(client: Socket) {
        try {
            client.emit(
                CallbreakWebSocketEvents.AUTH_ERROR,
                JSON.stringify({
                    error: true,
                    message: 'Authorization token not provided or invalid.',
                    statusCode: HttpStatus.UNAUTHORIZED,
                    messageCode: 'UNAUTHORIZED',
                    errorMessage: 'Authorization token not provided or invalid',
                }),
            );
            setTimeout(() => client.disconnect(), 500);
        } catch (error) {
            console.log(
                'Getting error while handle  emit [ auth-error ]',
                error,
            );
            return;
        }
    }

    private async verifyUserAccess(
        userId: number,
    ): Promise<Partial<User> | null> {
        try {
            const user = await this.userService.findOneById(userId);

            if (!user) {
                return null;
            }
            if (Number(user?.status) === 0) {
                return null;
            }
            if (user.role !== Role.User) {
                return null;
            }

            return {
                id: user.id,
                name: user.name,
                wallet: user.wallet,
                profile_pic: user.profile_pic,
                bonus_wallet: user.bonus_wallet,
                winning_wallet: user.winning_wallet,
                unutilized_wallet: user.unutilized_wallet,
                is_online: user.is_online,
            };
        } catch (error) {
            console.error('Getting error while verifying user access:', error);
            return null;
        }
    }
}
