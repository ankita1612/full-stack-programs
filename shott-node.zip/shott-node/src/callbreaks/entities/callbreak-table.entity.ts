import {
    Column,
    CreateDateColumn,
    Entity,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('callbreak_table')
export class CallbreakTable {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    boot_value: number;

    @Column({ default: true })
    status: boolean;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
