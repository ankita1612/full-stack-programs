import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { CallbreakRooms } from './callbreak-rooms.entity';
import { CallbreakRoomRounds } from './callbreak-room-rounds.entity';

@Entity('callbreak_score')
export class CallbreakScore {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user_id: number;

    @Column({ nullable: false })
    callbreak_room_id: number;

    @Column({ nullable: false })
    callbreak_round_id: number;

    @Column({ nullable: false })
    bet_value: number;

    @Column({ default: 0 })
    in_hand_value: number;

    @Column({ type: 'float', default: 0.0 })
    bonus_value: number;

    @Column({ type: 'float', default: 0.0 })
    points: number;

    @ManyToOne(() => CallbreakRooms, (room) => room.callbreak_score) // One-to-one relationship
    @JoinColumn({ name: 'callbreak_room_id' }) // Foreign key
    callbreak_room: CallbreakRooms;

    @ManyToOne(() => CallbreakRoomRounds, (round) => round.callbreak_score) // One-to-one relationship
    @JoinColumn({ name: 'callbreak_round_id' }) // Foreign key
    callbreak_round: CallbreakRoomRounds;

    @Column({ type: 'float', default: 0.0 })
    total_points: number;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
