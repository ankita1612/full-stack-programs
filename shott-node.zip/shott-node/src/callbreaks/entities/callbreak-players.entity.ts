import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { CallbreakRooms } from './callbreak-rooms.entity';

export enum RoomStatus {
    OPEN = 'open',
    CLOSED = 'closed',
}

@Entity('callbreak_players')
export class CallbreakPlayers {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: false })
    callbreak_room_id: number;

    @Column()
    callbreak_table_id: number;

    @Column()
    user_id: number;

    @Column({ type: 'json' })
    user_info: object;

    @Column({ default: false })
    is_master_player: boolean;

    @Column({ default: false })
    is_dealer: boolean;

    @Column({ default: false })
    is_active: boolean;

    @Column({ default: false })
    is_your_turn: boolean;

    @Column({ default: false })
    is_quit: boolean;

    @Column({ default: false })
    is_offline: boolean;

    @Column()
    player_position: number;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;

    @ManyToOne(() => CallbreakRooms, (room) => room.players, {
        onDelete: 'CASCADE',
    })
    @JoinColumn({ name: 'callbreak_room_id' })
    callbreak_room: CallbreakRooms;
}
