import { MasterCard } from 'src/master-cards/entities/master-card.entity';
import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('callbreak_card_distributions')
export class CallbreakCardDistributions {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    user_id: number;

    @Column()
    callbreak_rooms_id: number;

    @Column()
    callbreak_round_id: number;

    @Column({ default: 0 })
    master_card_id: number;

    @ManyToOne(() => MasterCard, (user) => user.callbreak_master_card_detail) // One-to-one relationship
    @JoinColumn({ name: 'master_card_id' }) // Foreign key
    master_card: MasterCard;

    @Column({ default: false })
    is_drop_card: boolean;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
