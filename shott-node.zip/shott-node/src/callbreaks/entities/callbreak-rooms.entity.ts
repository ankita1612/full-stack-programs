import {
    Column,
    CreateDateColumn,
    Entity,
    OneToMany,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { CallbreakPlayers } from './callbreak-players.entity';
import { CallbreakScore } from './callbreak-score.entity';

export enum RoomStatus {
    OPEN = 'open',
    PREPARING = 'preparing',
    PLAYING = 'playing',
    FINISHED = 'finished',
}

export enum GameStage {
    JOINING_PLAYERS = 1,
    GAME_START = 2,
    FIRST_ROUND_SET_BET_SCREEN = 3,
    FIRST_ROUND_PLAYING = 4,
    FIRST_ROUND_RESULT_SCREEN = 5,
    SECOND_ROUND_SET_BET_SCREEN = 6,
    SECOND_ROUND_PLAYING = 7,
    SECOND_ROUND_RESULT_SCREEN = 8,
    THIRD_ROUND_SET_BET_SCREEN = 9,
    THIRD_ROUND_PLAYING = 10,
    FINAL_RESULT_SCREEN = 12,
}

@Entity('callbreak_rooms')
export class CallbreakRooms {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    users_count: number;

    @Column()
    callbreak_table_id: number;

    @Column({ default: 0 })
    winner_user_id: number;

    @Column({ default: 1 })
    stage: number;

    @Column({ type: 'enum', enum: RoomStatus, default: RoomStatus.OPEN })
    status: string;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;

    @OneToMany(() => CallbreakPlayers, (player) => player.callbreak_room)
    players: CallbreakPlayers[];

    @OneToMany(() => CallbreakScore, (player) => player.callbreak_room)
    callbreak_score: CallbreakScore[];
}
