import { Suits } from 'src/master-cards/entities/master-card.entity';
import {
    Column,
    CreateDateColumn,
    Entity,
    OneToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';
import { CallbreakScore } from './callbreak-score.entity';

@Entity('callbreak_room_rounds')
export class CallbreakRoomRounds {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    round_number: number;

    @Column()
    callbreak_rooms_id: number;

    @Column({ default: false })
    is_current_round: boolean;

    @Column({ default: Suits.SPADES })
    trump_card: string;

    @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    last_card_drop_time: Date;

    @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
    next_card_drop_time: Date;

    @OneToOne(() => CallbreakScore, (player) => player.callbreak_round)
    callbreak_score: CallbreakScore;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
