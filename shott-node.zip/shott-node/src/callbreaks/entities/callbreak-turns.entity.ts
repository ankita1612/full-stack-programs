import { MasterCard } from 'src/master-cards/entities/master-card.entity';
import {
    Column,
    CreateDateColumn,
    Entity,
    JoinColumn,
    ManyToOne,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity('callbreak_turns')
export class CallbreakTurns {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: false })
    user_id: number;

    @Column({ nullable: false })
    card_id: number;

    @Column({ nullable: false })
    turn_number: number;

    @ManyToOne(() => MasterCard, (card) => card.callbreak_master_card_detail) // One-to-one relationship
    @JoinColumn({ name: 'card_id' }) // Foreign key
    master_card: MasterCard;

    @Column({ nullable: false })
    callbreak_room_id: number;

    @Column({ nullable: false })
    callbreak_round_id: number;

    @Column({ default: false })
    is_winner: boolean;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
