import {
    Controller,
    Get,
    Post,
    Body,
    Patch,
    Param,
    Delete,
    UseGuards,
    Req,
    ParseIntPipe,
    Query,
} from '@nestjs/common';
import { CallbreaksService } from './callbreaks.service';
import { CreateCallbreakDto } from './dto/create-callbreak.dto';
import { UpdateCallbreakDto } from './dto/update-callbreak.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { ListDto } from 'src/user/dto/list.dto';

@Controller('callbreaks')
@UseGuards(JwtAuthGuard)
export class CallbreaksController {
    constructor(private readonly callbreaksService: CallbreaksService) {}

    // @Post()
    // create(@Body() createCallbreakDto: CreateCallbreakDto) {
    //   return this.callbreaksService.create(createCallbreakDto);
    // }

    @Get('/table')
    findAll() {
      return this.callbreaksService.findAll();
    }

    @Post('/user/join/table')
    check(
        @Req() req,
        @Body() body:any) {
      const user = req.user;
      return this.callbreaksService.joinTable(user,body);
    }


    @Post('/table')
    add(@Body() createCallbreakDto:CreateCallbreakDto) {
      const data = this.callbreaksService.addTable(createCallbreakDto);
      return data;
    }

    @Patch('/table/:id')
    update(@Param('id',ParseIntPipe) id:number, @Body() updateCallbreakDto:UpdateCallbreakDto) {
      const data = this.callbreaksService.updateTable(id,updateCallbreakDto);
      return data;
    }

    @Get('/admin/table')
    get(@Query() reqQuery:ListDto) {
      return this.callbreaksService.get(reqQuery);
    }

    // @Get(':id')
    // findOne(@Param('id') id: string) {
    //   return this.callbreaksService.findOne(+id);
    // }

    // @Patch(':id')
    // update(@Param('id') id: string, @Body() updateCallbreakDto: UpdateCallbreakDto) {
    //   return this.callbreaksService.update(+id, updateCallbreakDto);
    // }

    // @Delete(':id')
    // remove(@Param('id') id: string) {
    //   return this.callbreaksService.remove(+id);
    // }
}
