import { Test, TestingModule } from '@nestjs/testing';
import { CallbreaksService } from './callbreaks.service';

describe('CallbreaksService', () => {
    let service: CallbreaksService;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [CallbreaksService],
        }).compile();

        service = module.get<CallbreaksService>(CallbreaksService);
    });

    it('should be defined', () => {
        expect(service).toBeDefined();
    });
});
