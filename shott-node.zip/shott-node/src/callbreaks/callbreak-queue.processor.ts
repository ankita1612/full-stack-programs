import { Processor, Process } from '@nestjs/bull';
import { Job } from 'bull';
import { CallbreaksService } from './callbreaks.service';

@Processor('callbreakQueue')
export class CallbreakQueueProcessor {
    constructor(private readonly callbreaksService: CallbreaksService) {}

    @Process('assignCallbreakRoom')
    async handleAssignRoom(job: Job) {
        return this.callbreaksService.addPlayerToRoom(job.data);
    }
}
