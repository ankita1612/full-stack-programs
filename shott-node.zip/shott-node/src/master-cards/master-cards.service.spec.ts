import { Test, TestingModule } from '@nestjs/testing';
import { MasterCardsService } from './master-cards.service';

describe('MasterCardsService', () => {
  let service: MasterCardsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MasterCardsService],
    }).compile();

    service = module.get<MasterCardsService>(MasterCardsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
