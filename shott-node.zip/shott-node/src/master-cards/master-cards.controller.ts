import {
    Controller,
    Get,
    Param,
    UseGuards,
    Query,
    HttpStatus,
} from '@nestjs/common';
import { MasterCardsService } from './master-cards.service';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { RoleAndPermissionGuard } from 'src/roles-permissions.guard';
import { Permissions, Roles } from 'src/roles-permissions.decorator';
import { ListDto } from 'src/user/dto/list.dto';
import { PermissionModule } from 'src/common/enums/user.permission';
import { Role } from 'src/common/enums/role.enum';

@Controller('master-cards')
@UseGuards(JwtAuthGuard)
export class MasterCardsController {
    constructor(private readonly masterCardsService: MasterCardsService) {}

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.MasterCard)
    @Get('/list')
    getMastercardList(@Query() reqQuery: ListDto) {
        return this.masterCardsService.getMastercardList(reqQuery);
    }

    @UseGuards(RoleAndPermissionGuard)
    @Roles(Role.Admin, Role.SubAdmin)
    @Permissions(PermissionModule.MasterCard)
    @Get('/:id')
    getMasterCard(@Param('id') id: string) {
        return this.masterCardsService.findOneById(+id);
    }
}
