import { PartialType } from '@nestjs/mapped-types';
import { CreateMasterCardDto } from './create-master-card.dto';

export class UpdateMasterCardDto extends PartialType(CreateMasterCardDto) {}
