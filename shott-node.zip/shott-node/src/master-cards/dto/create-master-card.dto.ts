import { IsString } from 'class-validator';

export class CreateMasterCardDto {
    @IsString()
    image: string;
}
