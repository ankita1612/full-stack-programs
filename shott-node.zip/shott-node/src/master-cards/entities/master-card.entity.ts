import { CallbreakCardDistributions } from 'src/callbreaks/entities/callbreak-card-distributions.entity';
import { CallbreakTurns } from 'src/callbreaks/entities/callbreak-turns.entity';
import {
    Column,
    CreateDateColumn,
    Entity,
    OneToMany,
    PrimaryGeneratedColumn,
    UpdateDateColumn,
} from 'typeorm';

export enum Suits {
    HEARTS = 'Hearts',
    DIAMONDS = 'Diamonds',
    CLUBS = 'Clubs',
    SPADES = 'Spades',
}
export enum Ranks {
    TWO = '2',
    THREE = '3',
    FOUR = '4',
    FIVE = '5',
    SIX = '6',
    SEVEN = '7',
    EIGHT = '8',
    NINE = '9',
    TEN = '10',
    J = 'J',
    Q = 'Q',
    K = 'K',
    A = 'A',
}

@Entity('master_cards')
export class MasterCard {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ type: 'enum', enum: Ranks })
    rank: string;

    @Column({ type: 'enum', enum: Suits })
    suit: string;

    @Column()
    weightage: number;

    @OneToMany(
        () => CallbreakCardDistributions || CallbreakTurns,
        (card) => card.master_card,
        {
            nullable: true,
        },
    )
    callbreak_master_card_detail: CallbreakCardDistributions | CallbreakTurns;

    @CreateDateColumn({ type: 'timestamp' })
    created_at: Date;

    @UpdateDateColumn({ type: 'timestamp' })
    updated_at: Date;
}
