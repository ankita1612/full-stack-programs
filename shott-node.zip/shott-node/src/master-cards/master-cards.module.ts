import { Module } from '@nestjs/common';
import { MasterCardsService } from './master-cards.service';
import { MasterCardsController } from './master-cards.controller';
import { MasterCard } from './entities/master-card.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
    imports: [TypeOrmModule.forFeature([MasterCard])],
    controllers: [MasterCardsController],
    providers: [MasterCardsService],
})
export class MasterCardsModule {}
