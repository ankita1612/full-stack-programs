import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { MasterCard, Ranks, Suits } from './entities/master-card.entity';
import { ILike, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ListDto } from 'src/user/dto/list.dto';
import { logger } from 'src/logger/winston.logger';

@Injectable()
export class MasterCardsService {
    constructor(
        @InjectRepository(MasterCard)
        private masterCardRepository: Repository<MasterCard>,
    ) {}

    async onModuleInit() {
        const cards = await this.masterCardRepository.count({});
        if (cards === 0) {
            const suits = [
                Suits.HEARTS,
                Suits.DIAMONDS,
                Suits.CLUBS,
                Suits.SPADES,
            ];
            const ranks = [
                { rank: Ranks.TWO, weightage: 0 },
                { rank: Ranks.THREE, weightage: 1 },
                { rank: Ranks.FOUR, weightage: 2 },
                { rank: Ranks.FIVE, weightage: 3 },
                { rank: Ranks.SIX, weightage: 4 },
                { rank: Ranks.SEVEN, weightage: 5 },
                { rank: Ranks.EIGHT, weightage: 6 },
                { rank: Ranks.NINE, weightage: 7 },
                { rank: Ranks.TEN, weightage: 8 },
                { rank: Ranks.J, weightage: 9 },
                { rank: Ranks.Q, weightage: 10 },
                { rank: Ranks.K, weightage: 11 },
                { rank: Ranks.A, weightage: 12 },
            ];
            // FUNCTION TO GENERATE THE DECK OF CARDS
            function generateDeck() {
                const deck = [];
                ranks.forEach((rank) => {
                    suits.forEach((suit) => {
                        // let image = 'public/master-cards/';

                        // if (suit === Suits.HEARTS) {
                        //     image = image + `rp${rank.toLowerCase()}.png`;
                        // } else if (suit === Suits.DIAMONDS) {
                        //     image = image + `rs${rank.toLowerCase()}.png`;
                        // } else if (suit === Suits.CLUBS) {
                        //     image = image + `bl${rank.toLowerCase()}.png`;
                        // } else if (suit === Suits.SPADES) {
                        //     image = image + `bp${rank.toLowerCase()}.png`;
                        // }

                        deck.push({
                            rank: rank.rank,
                            suit,
                            weightage: rank.weightage,
                        });
                    });
                });
                return deck;
            }

            console.log(generateDeck());

            await this.masterCardRepository.save(generateDeck());
        }
    }

    async getMastercardList(reqQuery: ListDto) {
        try {
            const page = reqQuery.page ? parseInt(reqQuery.page) : 1;
            const limit = reqQuery.limit ? parseInt(reqQuery.limit) : 10;
            const offset = (page - 1) * limit;

            const [result, count] =
                await this.masterCardRepository.findAndCount({
                    where: [
                        {
                            suit: ILike(`%${reqQuery.search}%`),
                        },
                        {
                            rank: ILike(`%${reqQuery.search}%`),
                        },
                    ],
                    select: {
                        id: true,
                        suit: true,
                        rank: true,
                        weightage: true,
                    },
                    order: {
                        created_at: 'DESC',
                    },
                    take: limit,
                    skip: offset,
                });

            const totalPages = Math.ceil(count / limit);
            const currentPage = page;
            return {
                statusCode: HttpStatus.OK,
                message: 'Master cards fetched successfully.',
                data: {
                    docs: result,
                    count,
                    totalPages,
                    currentPage,
                },
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

    async findOneById(
        id: number,
    ): Promise<{ message: string; statusCode: HttpStatus; data: MasterCard }> {
        try {
            const card = await this.masterCardRepository.findOne({
                where: { id },
                select: {
                    id: true,
                    suit: true,
                    rank: true,
                    weightage: true,
                },
            });

            if (!card) {
                throw new HttpException(
                    'Card not found.',
                    HttpStatus.NOT_FOUND,
                );
            }

            return {
                message: 'Master card fetched successfully.',
                statusCode: HttpStatus.OK,
                data: card,
            };
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}
