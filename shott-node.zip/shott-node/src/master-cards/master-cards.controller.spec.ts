import { Test, TestingModule } from '@nestjs/testing';
import { MasterCardsController } from './master-cards.controller';
import { MasterCardsService } from './master-cards.service';

describe('MasterCardsController', () => {
  let controller: MasterCardsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [MasterCardsController],
      providers: [MasterCardsService],
    }).compile();

    controller = module.get<MasterCardsController>(MasterCardsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
